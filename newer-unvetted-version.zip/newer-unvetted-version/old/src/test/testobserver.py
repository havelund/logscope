
from lsm.lsm import *

from eventdefs import *
import unittest

### specification ###

class TestObserver(unittest.TestCase):
    def setUp(self):
        self.c1 = newCmd(1)
        self.c2 = newCmd(2)
        self.e1 = newEvr(1)
        self.e2 = newEvr(2)
        self.e3 = newEvr(3)
        self.e4 = newEvr(4)

    def test1(self):
        "testing the observer\n"

        ### writing specfication ###
            
        wspec = SpecWriter("writtenspec")

        S1 = wspec.addState("S1",mode=StateMode.ALWAYS) 
        S2 = wspec.addState("S2") 
        S3 = wspec.addState("S3")   
        S4 = wspec.addState("S4")
        S5 = wspec.addState("S5")

        wspec.initial(S1)
        wspec.forbidden([S3,S4,S5])

        S1.rule(cmd({"id":1}),S2)
        S2.rule(cmd({"id":2}),[S3,S5])
        S3.rule(evr({"eventId":1}),S4)
        S4.rule(evr({"eventId":2}),wspec.done)
        S5.rule(evr({"eventId":3}),wspec.done)
        S5.rule(evr({"eventId":4}),wspec.error)

        ### learned spec ###
        
        log1 = [self.c1,self.c2,self.e1,self.e3,self.e2]
        log2 = [self.c2,self.c1,self.e1,self.e2,self.e4]
        
        lspec = Specification("learnedspec")

        learner = ExactLearner(lspec)
        learner.learnlog(log1)
        learner.learnlog(log2)

        ### monitoring ###

        obs = Observer([wspec,lspec])

        obs.monitor(log1)
        obs.monitor(log2)

        log3 = [self.c1,self.c2,self.e1,self.e2]
        log4 = [self.c1,self.c2,self.e1,self.e2,self.e4,self.e3]

        obs.monitor(log3)
        obs.monitor(log4)

if __name__ == '__main__':
    unittest.main()