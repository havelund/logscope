
from lsm.lsm import *

from eventdefs import *
import unittest

import copy

### specification ###

class TestParameters(unittest.TestCase):
    def setUp(self):
        self.c1 = newCmd(1)
        self.c2 = newCmd(2)
        self.e1 = newEvr(1)
        self.e2 = newEvr(2)
        self.e3 = newEvr(3)
        self.d1 = newDpr(1)
        self.d2 = newDpr(2)
        self.d3 = newDpr(3)

    def test1(self):

        ### specification ###
            
        s = SpecWriter("myspec")

        S1 = s.addState("S1",mode=ALWAYS) 
        S2 = s.addState("S2",[v.x]) 
        S3 = s.addState("S3",[v.x,v.y])   
        S4 = s.addState("S4",[v.y])
        S5 = s.addState("S5",[v.x,v.y])

        s.initial(S1)
        s.forbidden([S3,S4,S5])

        S1.rule(cmd({"id":v.x}),target(S2,v.x))
        S2.rule(cmd({"id":v.y}),[target(S3,[v.x,v.y]),target(S5,[v.x,v.y])])
        S3.rule(evr({"eventId":v.x}),target(S4,v.y))
        S4.rule(evr({"eventId":v.y}),s.done)
        S5.rule(dpr({"id":v.x}),s.done)
        S5.rule(dpr({"id":v.y}),s.error)

        ### monitoring ###

        mon = Monitor(s)

        log1 = [self.c1,self.c2,self.e1,self.e2,self.d1]    # good log
        log2 = [self.c2,self.c1,self.e2,self.e1,self.d2]    # good log
        log3 = [self.c1,self.c2,self.e1,self.d1,self.e2]    # good log
        log4 = [self.c1,self.c2,self.e2,self.e1,self.d2]    # bad log 
        log5 = [self.c1,self.c2,self.e1,self.d2,self.e2]    # bad log 
        mon.monitor(log1)
        mon.monitor(log2)
        mon.monitor(log3)
        mon.monitor(log4)   
        mon.monitor(log5)    

if __name__ == '__main__':
    unittest.main()

