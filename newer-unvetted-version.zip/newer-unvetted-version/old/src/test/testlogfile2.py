
from lsm.lsm import *
 
import unittest
  
class TestLogFile2(unittest.TestCase):

    def test1(self):
           
        ### specification 1 ###
                                    
        spec1 = SpecWriter("CommandSuccess")

        start = spec1.addState("start",mode=ALWAYS) 
        wait_VC0_dispatch = spec1.addState("wait_VC0_dispatch",[v.x]) 
        wait_VC1_dispatch = spec1.addState("wait_VC1_dispatch",[v.x, v.y]) 
        wait_VC1_success = spec1.addState("wait_VC1_success",[v.x, v.y])
        end_VC1 = spec1.addState("end_VC1",[v.x,v.y])

        spec1.initial(start)
        spec1.forbidden([wait_VC0_dispatch,wait_VC1_dispatch,wait_VC1_success])

        start.rule(cmd({"Stem":v.x,"Type" : "FlightSoftwareCommand", "Number": v.y}),target(wait_VC1_dispatch,[v.x, v.y]))
        start.rule(cmd({"Stem":v.x,"Type" : "HardwareCommand"}),target(wait_VC0_dispatch,v.x))
        wait_VC0_dispatch.rule(evr({"VC0Dispatch":v.x}),spec1.done)
        wait_VC0_dispatch.rule(evr({"DispatchFailure":v.x}),spec1.error)
        wait_VC1_dispatch.rule(evr({"DispatchFailure":v.x}),spec1.error)
        wait_VC1_dispatch.rule(evr({"VC1Dispatch":v.x, "Number": v.y}),target(wait_VC1_success,[v.x, v.y]))
        wait_VC1_success.rule(evr({"Success":v.x, "Number": v.y}),target(end_VC1,[v.x,v.y]))
        wait_VC1_success.rule(evr({"Failure":v.x, "Number": v.y}),spec1.error)
        end_VC1.rule(evr({"Success":v.x, "Number": v.y}),[target(end_VC1,[v.x,v.y]),spec1.error])

        ### specification 2 ###
                                    
        spec2 = SpecWriter("CommandFailure")

        start = spec2.addState("start",mode=ALWAYS) 

        spec2.initial(start)

        start.rule(evr({"Failure":v.x}),spec2.error)

        
        ### monitoring ###
 
        events = unpickle_logfile("/Users/khavelun/Desktop/MSLPICKLE/pickled_events.pic")

        mon1 = Monitor(spec1)
        mon2 = Monitor(spec2)
 
        obs = Observer([mon1,mon2])
 
        obs.monitor(events)
                
        Spreadsheet(mon1,"/Users/khavelun/Desktop/MSLPICKLE/spreadsheet.txt")
        
if __name__ == '__main__':
    unittest.main()
