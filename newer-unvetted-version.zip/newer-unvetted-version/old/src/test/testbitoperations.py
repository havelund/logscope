
import unittest

import lsm.lsm as lsm

class TestBitOperations(unittest.TestCase):
  
    def test1(self):        
 
        lsm.setDotDir("/Users/khavelun/Desktop/MSLDOT")
   
        observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec4")
        events = lsm.unpickle_logfile("/Users/khavelun/Desktop/MSLPICKLE/pickled_events.pic")
        
        results = observer.monitor(events)
        
        print "RESULTS:\n" , str(results)
                                
if __name__ == '__main__':
    unittest.main()
