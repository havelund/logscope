
from lsm.lsm import *

from eventdefs import *
import unittest

import copy

### specification ###

class TestCommands(unittest.TestCase):
    def setUp(self):
        self.c1 = newCmd("START")
        self.c2 = newCmd("STOP")
        self.e1 = newEvr("START")
        self.e2 = newEvr("STOP")
        self.e3 = newEvr("FIRE")
        self.d1 = newDpr("START")
        self.d2 = newDpr("STOP")
        self.d3 = newDpr("FIRE")

    def test1(self):

        ### specification ###
            
        class Statistics:
            def __init__(self):
                self.data = {}

            def increment(self,id,index):
                if not id in self.data:
                    self.data[id] = [0,0,0]
                triple = self.data[id]
                triple[index] = triple[index] + 1
            
            def reset(self):
                self.data = {}
            
            def send(self,cmd):
                self.increment(cmd["id"],0)

            def dispatch(self,evr):
                self.increment(evr["eventId"],1)
                
            def complete(self,dpr):
                self.increment(dpr["id"],2)
                
            def __repr__(self):
                text = "\nCommand, Sent, Dispatched, Completed\n"
                for key,counts in self.data.iteritems():
                    [s,d,c] = counts
                    text += str(key) + ", " + str(s) + ", " + str(d) + ", " + str(c) + "\n"
                return text
                
        statistics = Statistics()          
                                    
        s = SpecWriter("CommandDispatch")

        S0 = s.addState("S0",mode=ALWAYS) 
        S1 = s.addState("S1",[v.x]) 
        S2 = s.addState("S2",[v.x])   


        s.initial(S0)
        s.forbidden([S1,S2])

        S0.rule(cmd({"id":v.x}),[target(S1,[v.x]),target(S2,[v.x])],statistics.send)
        S1.rule(evr({"eventId":v.x}),s.done,statistics.dispatch)
        S2.rule(dpr({"id":v.x}),s.done,statistics.complete)

        ### monitoring ###

        mon = Monitor(s)

        log1 = [self.c1,self.e1,self.c2,self.e3,self.e2,self.d3,self.d2,self.d1]    # good log
        log2 = [self.c1,self.c2,self.e2,self.d2,self.d1,self.c1,self.c2,self.e2,self.d2,self.d1]    # bad log

        mon.monitor(log1)
        print str(statistics)
        
        statistics.reset()
        mon.monitor(log2)
        print str(statistics)

if __name__ == '__main__':
    unittest.main()
    