

from eventdefs import *
from lsm.lsm import *
import unittest

class TestLearner(unittest.TestCase):
    def setUp(self):
        pass

    def test1(self):
        
        events = unpickle_logfile("/Users/khavelun/Desktop/MSLPICKLE/pickled_events.pic")
        
        spec = Specification("LogPattern")

        learner = ExactLearner(spec)
        learner.learnlog(events)

        mon = Monitor(spec)
        mon.monitor(events)

if __name__ == '__main__':
    unittest.main()
