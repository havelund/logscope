
from testcore import *
from testspeclang import *
from testobserver import *
from testparameters import *
from testcommands import *
from testlogfile import *
from testlogfile2 import *
from testlearner import *
from testparser import *
from testbitoperations import *
  
load = unittest.TestLoader().loadTestsFromTestCase
 
suite1 = unittest.TestSuite(
                            [
                             load(TestCore),
                             load(TestSpecLanguage),
                             load(TestObserver),
                             load(TestParameters),
                             load(TestCommands),
                             load(TestLogFile),
                             load(TestLogFile2),
                             load(TestLearner),
                             load(TestParser),
                             load(TestBitOperations)
                             ]
                            )
 
unittest.TextTestRunner(verbosity=2).run(suite1)

