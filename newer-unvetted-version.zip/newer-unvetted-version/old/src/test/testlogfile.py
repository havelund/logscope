
from lsm.lsm import *

import unittest

  
class TestLogFile(unittest.TestCase):

    def test1(self):

        ### read in log file ###
 
        events = unpickle_logfile("/Users/khavelun/Desktop/MSLPICKLE/pickled_events.pic")
 
 
        ### statistics ###
            
        class Statistics:
            def __init__(self):
                self.data = {}

            def increment(self,id,index):
                if not id in self.data:
                    self.data[id] = [0,0,0,0,0,0]
                tuple = self.data[id]
                tuple[index] = tuple[index] + 1
            
            def write(self,cmd,event):
                print "\n"  , cmd , ":" , self.data[cmd]
            
            def reset(self):
                self.data = {}
            
            def send(self,cmd):
                self.increment(cmd["Stem"],0)
                self.write(cmd["Stem"],cmd)

            def VC1_dispatch(self,evr):
                self.increment(evr["VC1Dispatch"],1)
                self.write(evr["VC1Dispatch"],evr)

            def fail_validate(self,evr):
                self.increment(evr["DispatchFailure"],2)
                self.write(evr["DispatchFailure"],evr) 
  
            def complete(self,evr):
                self.increment(evr["Success"],3)
                self.write(evr["Success"],evr)              

            def failure(self,evr):
                self.increment(evr["Failure"],4)
                self.write(evr["Failure"],evr) 

            def VC0_dispatch(self,evr):
                self.increment(evr["VC0Dispatch"],5)
                self.write(evr["VC0Dispatch"],evr)
 
            def __repr__(self):
                text = "\nCommand, Sent, VC1Dispatch, Validation Failure, Completed, Failed, VC0Dispatch\n"
                keys = self.data.keys()
                for key in sorted(self.data.keys()):
                    [x1,x2,x3,x4,x5,x6] = self.data[key]
                    text += str(key) + ", " + str(x1) + ", " + str(x2) + ", " + str(x3) + "," + str(x4) + ", " + str(x5) + ", " + str(x6) + "\n"
                return text
                
        statistics = Statistics()          
                     

        ### specification ###
                                    
        s = SpecWriter("CommandDispatch")

        start = s.addState("start",mode=ALWAYS) 
        wait_VC0_dispatch = s.addState("wait_VC0_dispatch",[v.x]) 
        wait_VC1_dispatch = s.addState("wait_VC1_dispatch",[v.x, v.y]) 
        wait_VC1_success = s.addState("wait_VC1_success",[v.x, v.y])
        end_VC1 = s.addState("end_VC1",[v.x,v.y])

        s.initial(start)
        s.forbidden([wait_VC0_dispatch,wait_VC1_dispatch,wait_VC1_success])

        start.rule(cmd({"Stem":v.x,"Type" : "FlightSoftwareCommand", "Number": v.y}),target(wait_VC1_dispatch,[v.x, v.y]),statistics.send)
        start.rule(cmd({"Stem":v.x,"Type" : "HardwareCommand"}),target(wait_VC0_dispatch,v.x),statistics.send)
        wait_VC0_dispatch.rule(evr({"VC0Dispatch":v.x}),s.done,statistics.VC0_dispatch)
        wait_VC0_dispatch.rule(evr({"DispatchFailure":v.x}),s.error,statistics.fail_validate)
        wait_VC1_dispatch.rule(evr({"DispatchFailure":v.x}),s.error,statistics.fail_validate)
        wait_VC1_dispatch.rule(evr({"VC1Dispatch":v.x, "Number": v.y}),target(wait_VC1_success,[v.x, v.y]),statistics.VC1_dispatch)
        wait_VC1_success.rule(evr({"Success":v.x, "Number": v.y}),target(end_VC1,[v.x,v.y]),statistics.complete)
        wait_VC1_success.rule(evr({"Failure":v.x, "Number": v.y}),s.error,statistics.failure)
        end_VC1.rule(evr({"Success":v.x, "Number": v.y}),[target(end_VC1,[v.x,v.y]),s.error],statistics.complete)
        
        ### monitoring ###

        Observer(s).monitor(events)
        
        results = open("/Users/khavelun/Desktop/MSLPICKLE/results.txt",'w')
        results.write(str(statistics))
        
if __name__ == '__main__':
    unittest.main()
    