
from lsm.lsm import *

### Events ###

def newCmd(id):
    return mkEvent(Names.cmd_class,{Names.cmd_id : id})

def newDpr(id):
    return mkEvent(Names.dpr_class,{Names.dpr_id : id})

def newEvr(id):
    return mkEvent(Names.evr_class,{Names.evr_id : id})

def newEha(id,dn):
    return mkEvent(Names.eha_class,{Names.eha_id : id,Names.eha_dn : dn})
