
import unittest

import lsm.lsm as lsm
   
class TestParser(unittest.TestCase):

    def test1(self):        

        lsm.setDotDir("/Users/khavelun/Desktop/MSLDOT")
   
        observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec3")
        events = lsm.unpickle_logfile("/Users/khavelun/Desktop/MSLPICKLE/pickled_events.pic")
        
        results = observer.monitor(events)
        
        #print "RESULTS:\n" , str(results)
                
        #statobs = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/CommandSuccess")
        #results = statobs.monitor(events)      
        #lsm.Spreadsheet(results[0],"/Users/khavelun/Desktop/MSLPICKLE/spreadsheet.txt")                
                
                
if __name__ == '__main__':
    unittest.main()
