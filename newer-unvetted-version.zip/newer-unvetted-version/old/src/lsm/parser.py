

# -----------------------------------------------------------------------------
# parser.py                           
#                                                         
# PLY lexer and parser for the LogScope specification language                          
# ----------------------------------------------------------------------------- 

import ply.lex as lex
import ply.yacc as yacc
 
from ast import *

__errors__ = False

#############
### Lexer ###
#############

tokens = (
    'AUTOMATON',
    'PATTERN',
    'ALWAYS',
    'STATE',
    'STEP',
    'INITIAL',
    'FORBIDDEN',
    'DONE',
    'ERROR',
    'SUCCESS',
    'COMMAND',
    'EVR',
    'EHA',
    'PRODUCT',
    'NAME',
    'NUMBER',  
    'STRING',  
    'TRANS'
    )

literals = [':',';',',','(',')','{', '}','[',']','!','=']

RESERVED = {
  "automaton"  : "AUTOMATON" ,
  "pattern"    : "PATTERN"   ,
  "always"     : "ALWAYS"    ,
  "state"      : "STATE"     ,
  "step"       : "STEP"      ,
  "initial"    : "INITIAL"   ,
  "forbidden"  : "FORBIDDEN" ,
  "success"    : "SUCCESS"   ,
  "done"       : "DONE"      ,
  "error"      : "ERROR"     ,
  "COMMAND"    : "COMMAND"   ,
  "EVR"        : "EVR"       ,
  "EHA"        : "EHA"       ,
  "PRODUCT"    : "PRODUCT"   
  }

def t_NAME(t):
    r'[a-zA-Z_][a-zA-Z0-9_]*'
    t.type = RESERVED.get(t.value, "NAME")
    return t

t_NUMBER      = r'\d+'
t_STRING      = r'\"([^\\\n]|(\\.))*?\"'
t_TRANS       = r'=>'

def t_comment_1(t):
    r'/\*(.|\n)*?\*/'
    t.lexer.lineno += t.value.count('\n')
    pass

def t_comment_2(t):
    r"[ ]*\043[^\n]*"  # \043 is '#'
    pass

t_ignore = " \t"

def t_newline(t):
    r'\n+'
    t.lexer.lineno += t.value.count("\n")

def find_column(input,token):
    i = token.lexpos
    while i > 0:
        if input[i] == '\n': break
        i -= 1
    column = (token.lexpos - i)+1
    return column

def t_error(t):
    global __errors__
    __errors__ = True
    lexpos = find_column(t.lexer.lexdata,t)
    print "lexer error, illegal character '%s', line '%s', pos '%s'" % (t.value[0],t.lineno,lexpos)
    t.lexer.skip(1)

# Build the lexer                                                                                                                 

lex.lex()


##############
### Parser ###
##############

### specifications ###

def p_specification(p):
    "specification : monitors"
    global __errors__
    if __errors__:
        p[0] = None
    else:
        p[0] = Specification(p[1])

def p_monitors_1(p):
    "monitors : monitor"
    p[0] = [p[1]]
    
def p_monitors_2(p):
    "monitors : monitors monitor"
    p[0] = p[1]
    p[0].append(p[2])
    
def p_monitor_1(p):
    "monitor : automaton"
    p[0] = p[1]

def p_monitor_2(p):
    "monitor : pattern"
    p[0] = p[1]

### automata ###

def p_automaton(p):
    "automaton : AUTOMATON NAME '{' states initial forbidden success '}'"
    p[0] = Automaton(name=p[2],states=p[4],initial=p[5],forbidden=p[6],success=p[7])

def p_states_1(p):
    "states :"
    p[0] = []

def p_states_2(p):
    "states : state"
    p[0] = [p[1]]

def p_states_3(p):
    "states : states state"
    p[0] = p[1]
    p[0].append(p[2])

def p_state_1(p):
    "state : statekind NAME '{' rules '}'"
    p[0] = State(mode=p[1],name=p[2],formals=[],rules=p[4])

def p_state_2(p):
    "state : statekind NAME '(' formals ')' '{' rules '}'"
    p[0] = State(mode=p[1],name=p[2],formals=p[4],rules=p[7])

def p_formals(p):
    "formals : names"
    p[0] = p[1]
    
def p_statekind(p):
    '''statekind : ALWAYS
                 | STATE
                 | STEP'''
    p[0] = p[1]

def p_rules_1(p):
    "rules :"
    p[0] = []

def p_rules_2(p):
    "rules : rule"
    p[0] = [p[1]]

def p_rules_3(p):
    "rules : rules rule"
    p[0] = p[1]
    p[0].append(p[2])

def p_rule(p):
    "rule : conditions TRANS actions"
    p[0] = Rule(p[1],p[3])

def p_conditions(p):
    "conditions : event" # only one for now
    p[0] = [p[1]]
   
def p_event(p):
    "event : type '{' constraints '}'"
    p[0] = Event(p[1],p[3])

def p_type(p):
    '''type : COMMAND 
            | EVR 
            | EHA 
            | PRODUCT'''
    p[0] = p[1]

def p_constraints_1(p):
    "constraints :"
    p[0] = []
    
def p_constraints_2(p):
    "constraints : constraint"
    p[0] = [p[1]]

def p_constraints_3(p):
    "constraints : constraints ',' constraint"
    p[0] = p[1]
    p[0].append(p[3])

def p_constraint(p):
    "constraint : NAME ':' range"
    p[0] = Constraint(p[1],p[3])

def p_range_1(p):
    "range : NUMBER"
    p[0] = p[1]

def p_range_2(p):
    "range : STRING"
    p[0] = p[1]

def p_range_3(p):
    "range : '[' NUMBER ',' NUMBER ']'"
    p[0] = Interval(p[2],p[4])

def p_range_4(p):
    "range : '{' bitvalues '}'"
    p[0] = BitValues(p[2])

def p_range_5(p):
    "range : NAME"
    p[0] = Name(p[1]) 
 
def p_bitvalues_1(p):
    "bitvalues :"
    p[0] = {}

def p_bitvalues_2(p):
    "bitvalues : bitvalue"
    p[0] = p[1]

def p_bitvalues_3(p):
    "bitvalues : bitvalues ',' bitvalue"
    p[0] = p[1]
    p[0].update(p[3])

def p_bitvalue(p) :
    "bitvalue : NUMBER ':' value"
    p[0] = {p[1] : p[3]}

def p_value_1(p) :
    "value : NUMBER"
    p[0] = p[1]

def p_value_2(p):
    "value : STRING"
    p[0] = p[1]

def p_actions_1(p):
    "actions : action"
    p[0] = [p[1]]

def p_actions_2(p):
    "actions : actions ',' action"
    p[0] = p[1]
    p[0].append(p[3])

def p_action_1(p):
    "action : NAME"
    p[0] = Action(p[1])

def p_action_2(p):
    "action : NAME '(' arguments ')'"
    p[0] = Action(p[1],p[3])

def p_action_3(p):
    "action : DONE"
    p[0] = Action(p[1])

def p_action_4(p):
    "action : ERROR"
    p[0] = Action(p[1])

def p_arguments_1(p):
    "arguments : argument"
    p[0] = [p[1]]

def p_arguments_2(p):
    "arguments : arguments ',' argument"
    p[0] = p[1]
    p[0].append(p[3])

def p_argument_1(p):
    "argument : NUMBER"
    p[0] = p[1]

def p_argument_2(p):
    "argument : STRING"
    p[0] = p[1]

def p_argument_3(p):
    "argument : NAME"
    p[0] = Name(p[1])

def p_initial_1(p):
    "initial :"
    p[0] = []

def p_initial_2(p):
    "initial : INITIAL actions"
    p[0] = p[2]

def p_forbidden_1(p):
    "forbidden :"
    p[0] = []

def p_forbidden_2(p):
    "forbidden : FORBIDDEN names"
    p[0] = p[2]

def p_names_1(p):
    "names : NAME"
    p[0] = [p[1]]

def p_names_2(p):
    "names : names ',' NAME"
    p[0] = p[1]
    p[0].append(p[3])
    
def p_success_1(p):
    "success :" 
    p[0] = []

def p_success_2(p):
    "success : SUCCESS names"
    p[0] = p[2]


### patterns ###

def p_pattern(p):
    "pattern : PATTERN NAME ':' event TRANS consequence"
    p[0] = Pattern(name=p[2],event=p[4],consequence=p[6])

def p_consequence_1(p):
    "consequence : event"
    p[0] = p[1]

def p_consequence_2(p):
    "consequence : '!' event"
    p[0] = NegatedEvent(p[2])

def p_consequence_3(p):
    "consequence : '[' consequencelist ']'"
    p[0] = ConsequenceSequence(p[2])
    
def p_consequence_4(p):
    "consequence : '{' consequencelist '}'"
    p[0] = ConsequenceSet(p[2])

def p_consequencelist_1(p):
    "consequencelist : consequence"
    p[0] = [p[1]]

def p_eventlist_2(p):
    "consequencelist : consequencelist ',' consequence"
    p[0] = p[1]
    p[0].append(p[3])

def p_error(p):
    global __errors__
    __errors__ = True
    if p:
        print "Syntax error at '%s' in line '%s'" % (p.value , p.lineno)
    else:
        print "Syntax error at EOF"


##########################
### Running the parser ###
##########################

yacc.yacc()

def parse(file):
    data = open(file).read()
    spec = yacc.parse(data)
    return spec

#import sys
#if len(sys.argv) != 2:
#    print "expects an input file"
#else:
#    data = open(sys.argv[1]).read()
#    spec = yacc.parse(data)
#    print str(spec)
