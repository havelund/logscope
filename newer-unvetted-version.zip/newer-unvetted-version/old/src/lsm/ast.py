

# -----------------------------------------------------------------------------
# ast.py                           
#                                                         
# PLY abstract syntax (AST nodes) for the LogScope specification language                
# ----------------------------------------------------------------------------- 


###########################
### auxiliary functions ###
###########################

INDENT = 0

def indent():
    global INDENT
    INDENT = INDENT + 1

def dedent():
    global INDENT
    INDENT = INDENT - 1

def spaces():
    global INDENT
    spaces = ""
    for x in range(0,INDENT):
        spaces += "  "
    return spaces

def list2string(list):
    comma = False
    text = ""
    for elem in list:
        if comma:
            text += ", "
        else:
            comma = True
        text += str(elem)
    return text


#################
### AST Nodes ###
#################

class Specification:
    def __init__(self,monitors):
        self.monitors = monitors

    def __repr__(self):
        text = "\n"
        for monitor in self.monitors:
            text += str(monitor) + "\n\n"
        return text

class Automaton:
    def __init__(self,name,states,initial,forbidden,success):
        self.name = name
        self.states = states
        self.initial = initial
        self.forbidden = forbidden
        self.success = success

    def __repr__(self):
        text = ""
        text = "automaton " + self.name + " {\n"
        indent()
        for state in self.states:
            text += str(state)
        text += "  initial " + list2string(self.initial) + "\n"
        if self.forbidden != []:
            text += "  forbidden " + list2string(self.forbidden) + "\n"
        if self.success != []:
            text += "  success " + list2string(self.success) + "\n"
        dedent()
        text += "}"
        return text

class State:
    def __init__(self,mode,name,formals,rules):
        self.mode = mode
        self.name = name
        self.formals = formals
        self.rules = rules

    def __repr__(self):
        if self.formals != []:
            formalstext = "(" + list2string(self.formals) + ")"
        else:
            formalstext = ""
        text = spaces() + self.mode + " " + self.name + formalstext + " {\n"
        indent()
        for rule in self.rules:
            text += str(rule)
        dedent()
        text += spaces() + "}\n\n"
        return text

class Rule:
    def __init__(self,conditions,actions):
        self.conditions = conditions
        self.actions = actions

    def __repr__(self):
        return spaces() + list2string(self.conditions) + " => " + list2string(self.actions) + "\n"

class Event:
    def __init__(self,type,constraints):
        self.type = type
        self.constraints = constraints

    def __repr__(self):
        return self.type + "{" + list2string(self.constraints) + "}"

class Constraint:
    def __init__(self,name,range):
        self.name = name
        self.range = range

    def __repr__(self):
        return self.name + " : " + str(self.range)

class Name:
    def __init__(self,name):
        self.name = name
        
    def __repr__(self):
        return self.name

class Interval:
    def __init__(self,left,right):
        self.left = left
        self.right = right

    def __repr__(self):
        return "[" + str(self.left) + "," + str(self.right) + "]"

class BitValues:
    def __init__(self,dict):
        self.dict = dict

    def __repr__(self):
        text = "{"
        maybecomma = ""
        for bit in sorted(self.dict.keys()):
            value = self.dict[bit]
            text += maybecomma + str(bit) + ":" + str(value)
            maybecomma = ","
        text += "}"
        return text
        
class Action:
    def __init__(self,name,actuals=[]):
        self.name = name
        self.actuals = actuals

    def __repr__(self):
        text = self.name
        if self.actuals != []:
            text += "(" + list2string(self.actuals) + ")"
        return text

class Pattern:
    def __init__(self,name,event,consequence):
        self.name = name
        self.event = event
        self.consequence = consequence

    def __repr__(self):
        text = "pattern " + self.name + " :\n"
        indent()
        text += spaces() + str(self.event) + " =>\n"
        indent()
        text += spaces() + str(self.consequence)
        dedent()
        dedent()
        return text
    
class NegatedEvent:
    def __init__(self,event):
        self.event = event

    def __repr__(self):
        return "!" + str(self.event)

def  consequences2string(consequencelist,begin,end):
    text = begin + "\n"
    indent()
    length = len(consequencelist)
    for index in range(0,length-1): # goes from 0 to (length-1)-1
        text += spaces() + str(consequencelist[index]) + ",\n"
    text += spaces() + str(consequencelist[length-1]) + "\n"
    dedent()
    text += spaces() + end
    return text

class ConsequenceSequence:
    def __init__(self,consequencelist):
        self.consequencelist = consequencelist

    def __repr__(self):
        return consequences2string(self.consequencelist,"[","]")

class ConsequenceSet:
    def __init__(self,consequencelist):
        self.consequencelist = consequencelist

    def __repr__(self):
        return consequences2string(self.consequencelist,"{","}")

