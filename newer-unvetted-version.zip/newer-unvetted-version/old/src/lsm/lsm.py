
import sys
import string
import pickle
import event_list
from parser import yacc
import ast
 
### Options ###

class Options:
    dotdir = "."
    debug = False
    inform = False
    reportevents = False
    once = True # not needed to be True for the moment
    filter = True
    statistics = True
    printstatistics = False

def setDotDir(dir):
    print "dot files (spec visualizations) will be stored in :" , dir
    Options.dotdir = dir

### events ###

class Names:
    cmd_class = "COMMAND"   # Cmd
    evr_class = "EVR"       # Evr
    eha_class = "EHA"       # Eha
    dpr_class = "PRODUCT"   # Dpr
    cmd_id = "Stem"
    dpr_id = "id"
    evr_id = "EventID"
    eha_id = "ChannelId"
    eha_dn = "DataNumber"
    cmd_scet = "SCET"
    evr_scet = "SCET"
    eha_scet = "SCET"
    dpr_scet = "SCET"

def mkEvent(kind,fields):
    event = fields.copy()
    event["OBJ_TYPE"] = kind
    return event

def strCmd(cmd):
    return "cmd(" + str(cmd) + ")"

def strDpr(dpr):
    return "dpr(" + str(dpr) + ")"

def strEvr(evr):
    return "evr(" + str(evr) + ")"

def strEha(eha):
    return "chan(" + str(eha) + ")"
        
def strEvent(event):
    if isCmd(event):
        return strCmd(event)
    if isDpr(event):
        return strDpr(event)
    if isEvr(event):
        return strEvr(event)
    if isEha(event):
        return strEha(event)
    print str(event)
    assert False

def isCmd(event):
    return eventKind(event) == Names.cmd_class

def isEvr(event):
    return eventKind(event) == Names.evr_class

def isDpr(event):
    return eventKind(event) == Names.dpr_class

def isEha(event):
    return eventKind(event) == Names.eha_class

def getScet(event):
    if isCmd(event):
        return event[Names.cmd_scet]
    if isEvr(event):
        return event[Names.evr_scet]
    if isEha(event):
        return event[Names.eha_scet]
    if isDpr(event):
        return event[Names.dpr_scet]
    assert False # we should not reach this point

def compare(event1,event2):
    scet1 = getScet(event1)
    scet2 = getScet(event2)
    if scet1 < scet2:
        return -1
    if scet1 == scet2:
        return 0
    if scet1 > scet2:
        return 1  


### auxiliary functions and classes ###

def debug(str):
    if Options.debug:
        print "--" , str

def inform(str):
    if Options.inform:
        print "--" , str 

def dump(str):
    print str

def min(x,y):
    if x <= y:
        return x
    else:
        return y
    
def max(x,y):
    if x >= y:
        return x
    else:
        return y

def exists(list1,list2):
    for element in list1:
        if element in list2:
            return True
    return False
          
def createRules(conditions,target):
    rules = []
    for condition in conditions:    
        rules.append(Rule([condition],[target]))
    return rules

def eventKind(event):
    return event["OBJ_TYPE"]

def startswith(str1,str2):
    return string.count(str1,str2,0,len(str2)) > 0

def containsError(states):
    for state in states:
        if state.isErrorState():
            return True
    return False

def list2string(list,sep=","):
    text = ""
    separator = False
    for element in list:
        if separator:
            text += sep
        else:
            separator = True
        text += str(element)
    return text

def dict2string(dictionary,format):
    text = "{\n"
    for field,val in dictionary.iteritems():
        text += "  " + str(field) + " : " + format(val) + "\n"
    text += "}\n"
    return text

def listonlines(list):
    text = ""
    for e in list:
        text += str(e) + "\n"
    return text
            
def sort(listoflists):
    onelist = []
    for list in listoflists:
        onelist += list
    return sorted(onelist,compare)   

def aFuture(states):
    for state in states:
        if not state.isErrorState():
            return True
    return False

def eventString(event,counter=""):
    if counter == "":
        eventnr = " "
    else:
        eventnr = " " + str(counter) + " "
    text = event["OBJ_TYPE"] + eventnr + "{\n"
    for field,val in event.iteritems():
        text += "  " + str(field) + " := " + str(val) + "\n"
    text += "}\n"
    return text


### bit and index operations ###

def getBitValue(n, p):
    '''
    get the bitvalue of denary (base 10) number n at the equivalent binary
    position p (binary count starts at position 0 from the right)
    '''
    return (int(n) >> int(p)) & 1

def indexMatch(source,index,value):
    assert isinstance(index,int)
    if isinstance(source,int):
        if index <= 15: 
            return getBitValue(source,index) == value
    elif isinstance(source,list) or isinstance(source,str):
        if index < len(source):
            return source[index] == value
    elif isinstance(source,dict):
        if index in source:
            return source[index] == value
    return False


### exceptions and errors ###

class Bug(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

class Error:
    def __init__(self,location,message):
        self.location = location
        self.message = message

    def getMessage(self):
        return self.message
        
    def __repr__(self):
        return "  *** " + str(self.location) + " - " + self.message

def error(message):
    print "***" , message
    sys.exit()

### filtering ###

class Filter:
    def __init__(self):
        self.filter = {} # OBJ_TYPE -> (Key-set)-list
        
    def update(self,kind,conditionkeys):
        if not kind in self.filter:
            self.filter[kind] = []
        keysetlist = self.filter[kind]
        conditionkeyset = set(conditionkeys)
        for keyset in keysetlist:
            if keyset == conditionkeyset:
                return
        keysetlist.append(conditionkeyset)
    
    def relevant(self,event):
        kind = eventKind(event)
        if not kind in self.filter:
            return False
        else:
            eventkeys = set(event.keys())
            for keyset in self.filter[kind]:
                if keyset.issubset(eventkeys):
                    return True
            return False


### statistics ###

class Statistics:
    def __init__(self,dostatistics):
        self.dostatistics = dostatistics
        self.counts = {} # OBJ_TYPE -> ((Field -> Value) * int)-list
              
    def getCounts(self):
        return self.counts
              
    def __record__(self,kind,dictionary):
        if not kind in self.counts:
            self.counts[kind] = []
        counts = self.counts[kind]
        for index in range(0,len(counts)):
            (dict,count) = counts[index]
            if dict == dictionary:
                counts[index] = (dict,count+1)
                return
        counts.append((dictionary,1)) 

    def execute(self,condition,event,binding,newbinding):
        if self.dostatistics:
            debug("=========================")
            debug(str(condition) +"\n"  + eventString(event) + "\n" + str(binding) + str(newbinding))
            debug("=========================")
            kind = condition.getKind()
            constraints = condition.getConstraints()
            dictionary = {}
            for key,constraint in constraints.iteritems():
                if isinstance(constraint,VAL):
                    dictionary[key] = constraint.getValue()
                if isinstance(constraint,PAR):
                    name = constraint.getName()
                    if name in binding:
                        value = binding[name]
                    else:
                        if name in newbinding:
                            value = newbinding[name]
                        else:
                            raise Bug , "name " + name + " not defined in binding "  + str(binding) + " nor in "  + str(newbinding)
                    dictionary[key] = value
            self.__record__(kind,dictionary)

    def __repr__(self):
        text = "Statistics {\n"
        for eventkind in sorted(self.counts.keys()):
            pairlist = self.counts[eventkind]
            text += "  " + str(eventkind) + " :\n"
            for (dict,count) in pairlist:
                text += "      " + str(dict) + " -> " + str(count) + "\n"
        text += "}\n"
        return text 


### states ###

class StateMode:
    STEP = 1
    STATE = 2
    ALWAYS = 3

class StateDecl:
    def __init__(self,name,formals=[],mode=StateMode.STATE):
        self.name = name
        if isinstance(formals,list):
            self.formals = formals
        else: # one argument
            self.formals = [formals]
        self.mode = mode
        self.rules = []

    def getFullName(self):
        return self.name

    def getName(self):
        if startswith(self.name,"error"):
            return "error"
        if startswith(self.name,"done"):
            return"done"
        return self.name

    def getFormals(self):
        return self.formals

    def addRule(self,rule):
        self.rules.append(rule)

    def addRules(self,rules):
        for rule in rules:
            self.addRule(rule)

    def getRules(self):
        return self.rules

    def getMode(self):
        return self.mode

    def isErrorState(self):
        return self.getName() == "error"

    def isDoneState(self):
        return self.getName() == "done"

    def shortRepr(self):
        text = self.getName() 
        if self.formals != []:
            text += "(" + list2string(self.formals) + ")"   
        return text

    def shortReprWithBindings(self,bindings):
        text = self.getName() 
        if self.formals != []:
            actuals = [bindings[formal.getName()] for formal in self.formals]
            text += "(" + list2string(actuals) + ")"   
        return text

    def __repr__(self):
        if self.mode == StateMode.STEP:
            mode = " step "
        else:
            if self.mode == StateMode.STATE:
                mode = " state "
            else:
                mode = " always "
        text = mode + self.name 
        if self.formals != []:
            text += "(" + list2string(self.formals) + ")"   
        text += " {"
        if self.rules == []:
            text += "}"
        else:
            text += "\n"
            for rule in self.rules:
                text += "    " + str(rule) + "\n"
            text += "  }"
        return text
          
class Rule:
    def __init__(self,guard,action,operation=None):
        self.guard = guard # Condition-list
        self.action = action # Target-list
        self.operation = operation # event -> unit

    def getGuard(self):
        return self.guard
    
    def getAction(self):
        return self.action

    def executeOperation(self,event):
        if self.operation != None:
            self.operation(event)

    def updateFilter(self,filter):
        for condition in self.guard:
            condition.updateFilter(filter)

    def __repr__(self):
        text = ""
        text += list2string(self.guard)
        text += " => "
        text += list2string(self.action)
        return text   

    def reprWithBindings(self,bindings):
        text = ""
        text += list2string([condition.reprWithBindings(bindings) for condition in self.guard])
        text += " => "
        text += list2string(self.action) # we don't instantiate with bindings since it is an error transition (we should do)
        return text  
            

class Condition:
    def __init__(self,kind,constraints):
        self.kind = kind # string
        self.constraints = constraints # FieldName -m> (VAL | IVL | BIT | PAR)

    def getKind(self):
        return self.kind

    def getConstraints(self):
        return self.constraints     

    def thisKind(self,event):
        return eventKind(event) == self.kind
                      
    def matchesField(self,event,field):
        return self.thisKind(event) and ((not field in self.constraints) or (self.constraints[field].matches(event[field],{})))

    def matches(self,event,binding):
        if not self.thisKind(event):
            return None
        accumbinding = {}
        for field,constraint in self.constraints.iteritems():
            debug("checking constraint " + str(field) + " : " + str(constraint) + " in binding " + str(binding))
            if field in event:
                localbinding = constraint.matches(event[field],binding) 
            else:
                localbinding = None
            if localbinding == None:
                return None
            accumbinding.update(localbinding)
        return accumbinding

    def widen(self,field,value):
        assert field in self.constraints
        constraint = self.constraints[field]
        assert isinstance(constraint,IVL)
        constraint.widen(value)

    def updateFilter(self,filter):
        filter.update(self.kind,self.constraints.keys())

    def __repr__(self):
        return self.kind + str(self.constraints)

    def reprWithBindings(self,bindings):
        groundedConstraints = {}
        for field,constraint in self.constraints.iteritems():
            if isinstance(constraint,PAR):
                groundedConstraints[field] = bindings[constraint.getName()]
            else:
                groundedConstraints[field] = constraint # VAL or IVL or BIT
        return self.kind + str(groundedConstraints)

class VAL:
    def __init__(self,value):
        if isinstance(value,str):
            assert value.startswith("\"") and value.endswith("\"")
            self.value = value.replace("\"","") # for efficiency when checking
        else:
            self.value = value
    
    def getValue(self):
        return self.value
    
    def matches(self,value,binding):
        if value == self.value:
            return {}
        else:
            return None

    def __repr__(self):
        if isinstance(self.value,str):
            return "\"" + str(self.value) + "\""
        else:
            return str(self.value)

class IVL:
    def __init__(self,low,high):
        self.low = low
        self.high = high
        
    def matches(self,value,binding):
        if self.low <= value <= self.high:
            return {}
        else:
            return None
    
    def widen(self,value):
        self.low = min(self.low,value)
        self.high  = max(self.high,value)

    def __repr__(self):
        return "[" + str(self.low) + ":" + str(self.high) + "]"

class BIT:
    def __init__(self,dict):
        self.dict = dict
       
    def matches(self,value,binding):
        for index,result in self.dict.iteritems(): 
            if not indexMatch(value,index,result):
                return None
        return {} # it matches all index constraints

    def __repr__(self):
        text = "{"
        maybecomma = ""
        for bit in sorted(self.dict.keys()):
            value = self.dict[bit]
            text += maybecomma + str(bit) + ":" + value
            maybecomma = ","
        text += "}"
        return text

class PAR:
    def __init__(self,name):
        self.name = name

    def getName(self):
        return self.name

    def matches(self,value,bindings):
        debug("matching " + str(value) + " against name " + self.name + " with binding " + str(bindings))
        if self.name in bindings:
            if value == bindings[self.name]:
                return {} # success but no binding is generated
            else:
                return None # no match
        else:
            return {self.name : value} # match and binding is generated

    def __repr__(self):
        prefix = ""
        return prefix + self.name

class Target:
    def __init__(self,statedecl,actuals=[]):
        self.statedecl = statedecl
        self.actuals = actuals

    def getStateDecl(self):
        return self.statedecl

    def instantiate(self,bindings={}):
        localbindings = self.instantiateBindings(self.statedecl.getFormals(),self.actuals,bindings)      
        return State(self.statedecl,localbindings)

    def instantiateBindings(self,formals,actuals,bindings):
        assert len(formals) == len(actuals)
        localbindings = {}
        for index in range(0,len(formals)):
            formal = formals[index] # PAR("x") 
            actual = actuals[index]   # either a PAR("y") or a normal value
            if isinstance(actual,PAR):
                actualname = actual.getName()
                assert actualname in bindings
                localbindings[formal.getName()] = bindings[actualname]
            else:
                localbindings[formal.getName()] = actual
        return localbindings

    def __repr__(self):
        text = self.statedecl.getName()
        if self.actuals != []:
            text += "("  + list2string(self.actuals) + ")"
        return text      
        
        
### specification ###

class StateKind:
    INITIAL = 1
    NORMAL = 2
    SUCCESS = 3
    FORBIDDEN = 4
    ERROR = 5
    DONE = 6

class NameGenerator:
    def __init__(self,stem,number):
        self.stem = stem
        self.number = number
                        
    def next(self):
        self.number = self.number + 1
        return self.stem + str(self.number)

class Specification:
    def __init__(self,name):
        self.name = name
        self.statedecls = []
        self.initial = []
        self.forbidden = []
        self.success = []
        self.stategenerator = NameGenerator("S",0)
        self.errorgenetor = NameGenerator("error",0)
        self.donegenerator = NameGenerator("done",0)

    def getName(self):
        return self.name

    def addStateDecl(self,statedecl):
        self.statedecls.append(statedecl)
    
    def addInitial(self,target):
        self.initial.append(target)
    
    def getInitial(self):
        return self.initial
        
    def addForbidden(self,statedecl):
        self.forbidden.append(statedecl)
    
    def getForbidden(self):
        return self.forbidden
        
    def addSuccess(self,statedecl):
        self.success.append(statedecl)
                       
    def getSuccess(self):
        return self.success
                       
    def nextName(self):
        return self.stategenerator.next()                       
        
    def error(self):
        errorStateDecl = StateDecl(self.errorgenetor.next(),mode=StateMode.STEP)
        self.addStateDecl(errorStateDecl)
        return errorStateDecl
                       
    def done(self):
        doneStateDecl = StateDecl(self.donegenerator.next(),mode=StateMode.STEP)
        self.addStateDecl(doneStateDecl)
        return doneStateDecl
                       
    def wellformed(self):
        return True
             
    def getFilter(self):
        filter = Filter()
        for statedecl in self.statedecls:
            for rule in statedecl.getRules():
                rule.updateFilter(filter)
        return filter
                                              
    def __repr__(self):
        text = "\n\nautomaton " + self.name + " {\n"
        for statedecl in self.statedecls:
            if not statedecl.isErrorState() and not statedecl.isDoneState():
                text += str(statedecl) + "\n\n"
        text += "  initial "
        for init in self.initial:
            text += str(init) + " "
        text += "\n"
        if self.forbidden != []:
            text +=  "  forbidden "
            for forbid in self.forbidden:
                text += forbid.getName() + " "
            text += "\n"
        if self.success != []:
            text +=  "  success "
            for success in self.success:
                text += success.getName() + " "
            text += "\n"
        text += "}\n"
        return text

    def write(self):
        print str(self)
        self.dumpDot()

    def nodeDecl(self,statedecl):    
        kind = self.getKind(statedecl)
        mode = statedecl.getMode()
        modetxt = ""
        if mode == StateMode.ALWAYS:
            modetxt = "@ "
        if mode == StateMode.STEP:
            modetxt = "# "
        format = "label=\"" + modetxt + statedecl.shortRepr() + "\""
        if kind == StateKind.INITIAL:
            format += ",style=filled,color=lightgrey"
        if kind == StateKind.NORMAL:
            pass
        if kind == StateKind.SUCCESS:
            format += ",shape=doublecircle,color=green"
        if kind == StateKind.FORBIDDEN:
            format += ",shape=invhouse,color=red"
        if kind == StateKind.ERROR:
            format += ",style=filled,color=black,fontcolor=white"
        if kind == StateKind.DONE:
            pass
        decl = "node_" + statedecl.getFullName() + "[" + format + "];"
        return decl
    
    def getKind(self,statedecl):
        if statedecl in [target.getStateDecl() for target in self.initial]:
            return StateKind.INITIAL
        if statedecl in self.success:
            return StateKind.SUCCESS
        if statedecl in self.forbidden:
            return StateKind.FORBIDDEN
        if statedecl.isErrorState():
            return StateKind.ERROR
        if statedecl.isDoneState():
            return StateKind.DONE
        return StateKind.NORMAL

    def dumpDot(self):
        pointcount = 0
        dot = open(Options.dotdir + "/" + self.name + ".dot",'w')
        dot.write("digraph states {\n")
        dot.write("node [shape = circle];\n")
        for statedecl in self.statedecls:
            dot.write("    " + self.nodeDecl(statedecl) + "\n")
        for statedecl in self.statedecls:
            sourcenode = "node_" + statedecl.getFullName()
            for rule in statedecl.getRules():
                guard = list2string(rule.getGuard())
                label = "[label=\"" + guard.replace("\"","\\\"") + "\"]"
                if len(rule.getAction()) > 1:
                    pointcount = pointcount + 1
                    targetnode = "node_P" + str(pointcount)
                    dot.write("    " + targetnode + "[label=\"\",shape=triangle,color=blue]\n")
                    dot.write("    " + sourcenode + " -> " + targetnode + label + ";\n")
                    sourcenode = targetnode
                    label = "[color=blue,style=dotted]" # the nodes leading out of the AND-node are unlabelled
                for target in rule.getAction():
                    targetnode = "node_" + target.getStateDecl().getFullName()
                    dot.write("    " + sourcenode + " -> " + targetnode + label + ";\n")
        dot.write("}\n");


### monitor ###

class Results:
    def __init__(self,specname,errors,counts):
        self.specname = specname
        self.errors = errors   # Error-list
        self.counts = counts # OBJ_TYPE -> ((Field -> Value) * int)-list
    
    def getSpecName(self):
        return self.specname
    
    def getErrors(self):
        return self.errors
        
    def getCounts(self):
        return self.counts
    
    def __repr__(self):
        text = "\n"
        text += "============================\n"
        text += "       RESULTS FOR " + self.specname + ": \n"
        text += "============================\n\n"
        if self.errors == []:
            text += "No errors detected!\n"
        else:
            text += "Errors: " + str(len(self.errors)) + " {\n"
            for error in self.errors: 
                text += "    " + error.getMessage() + "\n"
            text += "}"
        text += "\n\n"
        if self.counts != {}:
            text += "Statistics {\n"
            for eventkind in sorted(self.counts.keys()):
                pairlist = self.counts[eventkind]
                text += "  " + str(eventkind) + " :\n"
                for (dict,count) in pairlist:
                    text += "      " + str(dict) + " -> " + str(count) + "\n"
            text += "}\n"
        return text

class State:
    def __init__(self,statedecl,bindings):
        self.statedecl = statedecl
        self.bindings = bindings

    def getStateDecl(self):
        return self.statedecl

    def getBindings(self):
        return self.bindings

    def isErrorState(self):
        return self.statedecl.isErrorState()
    
    def __repr__(self):
        return str(self.statedecl) + "\n  with bindings: " + str(self.bindings)
    
    def shortRepr(self):
        return self.statedecl.shortRepr() + " with bindings: " + str(self.bindings)
    
    def shortReprWithBindings(self):
        return self.statedecl.shortReprWithBindings(self.bindings)
    
class Monitor:
    def __init__(self,specification,learning=False,dostatistics=Options.statistics):
        if isinstance(specification,Specification):
            self.specification = specification
        else:
            self.specification = specification.getSpec()
        assert self.specification.wellformed()
        self.observations = []
        self.states = specification.initial
        self.learning = learning
        self.error = False
        self.errors = []
        if Options.filter and not self.learning:
            self.filter = self.specification.getFilter()
        else:
            self.filter = None
        self.dostatistics = dostatistics
        self.statistics = Statistics(dostatistics)
        self.eventnumber = 0
        print "monitored specification:"
        self.specification.write()
       
    def addObservation(self,obs):
        self.observations.append(obs)

    def getEvent(self):
        return self.observations[0] # assuming there is exactly one

    def addState(self,state):
        self.states.append(state)

    def getStates(self):
        return self.states

    def getResults(self,includeStatistics=True): 
        if includeStatistics:
            statCounts = self.statistics.getCounts()
        else:
            statCounts = {}
        return Results(self.specification.getName(),self.errors,statCounts)

    def trueCondition(self,condition,binding):
        for observation in self.observations:
            debug("examining observation: " + strEvent(observation))
            newbinding = condition.matches(observation,binding)
            if newbinding != None:
                self.statistics.execute(condition, observation, binding, newbinding)
                return newbinding
        return None
        
    def trueGuard(self,guard,binding):  
        accumbinding = {}
        for condition in guard:
            debug("testing condition " + str(condition))
            localbinding = self.trueCondition(condition,binding)
            if localbinding == None:
                debug("condition is false")
                return None
            debug("generating binding: " + str(localbinding))
            accumbinding.update(localbinding)
            debug("condition is true")
        return accumbinding

    def apply(self):
        errors = []
        states = []
        moveon = True
        for state in self.states:
            debug("checking state : " + state.shortRepr())
            statedecl = state.getStateDecl()
            fired = False
            if moveon:
                for rule in statedecl.getRules():
                    debug("testing rule: " + str(rule))
                    localbindings = self.trueGuard(rule.getGuard(),state.getBindings()) 
                    if localbindings != None:
                        debug("guard satisfied, adding actions") 
                        bindings = state.getBindings().copy()
                        bindings.update(localbindings)
                        newstates = [target.instantiate(bindings) for target in rule.getAction()]
                        states += newstates
                        fired = True
                        moveon = not Options.once
                        rule.executeOperation(self.getEvent()) # will execute if provided
                        if containsError(newstates):
                            location = self.specification.getName()
                            if Options.reportevents:
                                event = "\n\n" + eventString(self.getEvent()) + "\n"
                            else:
                                event = ""
                            error = Error(location, "event " + str(self.eventnumber) + " - " + state.shortReprWithBindings() + " : " + rule.reprWithBindings(bindings) + event)
                            errors += [error]
                            self.errormsg(str(error))
            if statedecl.mode == StateMode.ALWAYS or ((not fired) and statedecl.mode == StateMode.STATE):
                states += [state]
        debug("---> new set of states: \n" + listonlines(states))
        if states == [] and self.specification.getSuccess() != []:
            location = self.specification.getName()
            previousstates = [state.shortReprWithBindings() for state in self.states]
            if Options.reportevents:
                event = "\n\n" + eventString(self.getEvent()) + "\n"
            else:
                event = ""
            error = Error(location, "event " + str(self.eventnumber) + " terminates monitor in non-success state from state: " + str(previousstates) + event)
            errors += [error]
            self.errormsg(str(error))
        self.observations = []     
        self.states = states   
        self.error = not aFuture(self.states)
        return errors

    def begin(self):
        self.observations = []
        self.states = [target.instantiate() for target in self.specification.getInitial()]
        self.error = False
        self.errors = []
        self.eventnumber = 0
        self.statistics = Statistics(self.dostatistics)

    def next(self,event):
        self.eventnumber = self.eventnumber + 1
        if (self.learning or not Options.filter or self.filter.relevant(event)) and (not self.error or self.learning):
            debug("checking automaton: " + self.specification.getName())
            self.observations = [event]
            errors = self.apply()
            self.errors += errors
            return errors
        else:
            return []

    def end(self):
        location = self.specification.getName() + " end"
        errors = []
        if self.specification.forbidden != []:
            forbidden = [state for state in self.states if state.getStateDecl() in self.specification.forbidden]
            for state in forbidden:
                error = Error(location,"forbidden end state - " + state.shortReprWithBindings())
                errors += [error]
                # self.errormsg(str(error))
        if self.specification.success != []:
            if not exists(self.specification.success,[state.getStateDecl() for state in self.states]):
                error = Error(location,"none of the success states have been reached")
                errors += [error]
                # self.errormsg(str(error))
        self.errors += errors
        print(str(self.getResults(Options.printstatistics)))
        return errors

    def monitor(self,log):
        print "\n===== monitoring new log: =====\n"
        errors = []
        self.begin()
        for event in log:
            # inform(">>> next event: " + strEvent(event))
            errors += self.next(event)
        errors += self.end()
        return errors

    def errormsg(self,str):
        if not self.learning:
            print str


### observer ###

class Observer:
    def __init__(self,monitorThis=[]):
        if not isinstance(monitorThis,list):
            # it's a Specification, a specWriter, a Monitor or a file name
            requirements = [monitorThis]
        else:
            # it's a list of such
            requirements = monitorThis
        self.monitors = []
        for requirement in requirements:
            if isinstance(requirement,Monitor):
                self.monitors.append(requirement)
            elif isinstance(requirement,SpecWriter) or isinstance(requirement,Specification):
                # if it is a SpecWriter the Monitor will turn it into a Specification
                self.monitors.append(Monitor(requirement))
            else: # it must be a file name
                assert isinstance(requirement,str)
                specs = parse(requirement)
                if specs == None:
                    error("Monitoring terminated due to syntax error in specification")
                print str(specs)
                specWriters = internalSpec(specs)
                for specWriter in specWriters:
                    self.monitors.append(Monitor(specWriter))                

    def addMonitor(self,monitor):
        self.monitors.appened(monitor)
        
    def addSpec(self,specification):
        monitor = Monitor(specification)
        self.monitors.append(monitor)    

    def getResults(self):
        return [monitor.getResults() for monitor in self.monitors]

    def begin(self):
        for monitor in self.monitors:
            monitor.begin()

    def next(self,event):
        errors = []
        for monitor in self.monitors:
            errors += monitor.next(event)
        return errors

    def end(self):
        errors = []
        for monitor in self.monitors:
            errors += monitor.end()
        return errors

    def monitor(self,log):
        print "\n===== monitoring new log: =====\n"
        errors = []
        self.begin()
        for event in log:
            inform(">>> next event: " + strEvent(event))
            errors += self.next(event)
        errors += self.end()
        return self.getResults()


### learner ###

class Learner:
    pass


### interval learner ###

class IntervalLearner(Learner):
    def __init__(self,specification):
        self.spec = specification
        self.monitor = Monitor(specification,learning=True,dostatistics=False)
        self.ehamap = {} # EhaId -m-> Condition

    def getSpec(self):
        return self.spec
    
    def newStateDecl(self):
        return StateDecl(self.spec.nextName(),mode=StateMode.STEP)
    
    def begin(self):
        if self.spec.getInitial() == []:
            statedecl = self.newStateDecl()
            self.spec.addStateDecl(statedecl)
            self.spec.addInitial(Target(statedecl))
        self.monitor.begin()
        self.ehamap = {}
             
    def next(self,event):
        debug("next event: " + strEvent(event))
        if isEha(event) and not self.existingEhaEvent(event):            
            debug("this is an eha not in the eha map")
            condition = self.ehaOfRules(event)
            if condition != None:
                debug("refilling eha map with: " + str(condition))
                self.ehamap[event[Names.eha_id]] = condition
        if self.existingEhaEvent(event):
            debug("an existing EHA event, refine")
            self.refineEhaEvent(event)
            debug("refined condition: " + str(self.ehamap[event[Names.eha_id]]))
        pre_states = self.monitor.getStates()
        self.monitor.next(event)
        post_states = self.monitor.getStates()
        if post_states == []:
            debug("no new states ... now learning")
            inform("the following event causes learning: " + strEvent(event))
            condition = self.createCondition(event)
            targetstatedecl = self.newStateDecl()
            self.addEhaSelfLoops(targetstatedecl)
            target = Target(targetstatedecl)
            for sourcestate in pre_states:
                sourcestatedecl = sourcestate.getStateDecl()
                rule = Rule([condition],[target])
                sourcestatedecl.addRule(rule)
                debug("adding rule " + sourcestatedecl.getName() + " :" + str(rule))
            self.monitor.addState(target.instantiate())
            self.spec.addStateDecl(targetstatedecl)

    def end(self):
        for state in self.monitor.states:
            self.spec.addSuccess(state.getStateDecl())

    def ehaOfRules(self,event):
        for state in self.monitor.getStates():
            for rule in state.getStateDecl().getRules():
                for condition in rule.getGuard():
                    if condition.matchesField(event,Names.eha_id): 
                        return condition
        debug("did not find any rule with that eha condition")
        return None

    def existingEhaEvent(self,event):
        return isEha(event) and event[Names.eha_id] in self.ehamap 

    def refineEhaEvent(self,event):
        assert isEha(event) and event[Names.eha_id] in self.ehamap
        condition = self.ehamap[event[Names.eha_id]]
        eventdn = event[Names.eha_dn] 
        condition.widen(Names.eha_dn,eventdn)

    def createCondition(self,event):
        kind = eventKind(event)
        if isEha(event):
            ehaid = event[Names.eha_id]
            ehadn = event[Names.eha_dn]
            constraints = {Names.eha_id : VAL(ehaid) , Names.eha_dn : IVL(ehadn,ehadn)}
        if isEvr(event):
            evrid = event[Names.evr_id]
            constraints = {Names.evr_id : VAL(evrid)}
        if isDpr(event):
            dprid = event[Names.dpr_id]
            constraints = {Names.dpr_id : VAL(dprid)}
        if isCmd(event):
            cmdid = event[Names.cmd_id]
            constraints = {Names.cmd_id : VAL(cmdid)}        
        condition = Condition(kind,constraints)
        if isEha(event):
            self.ehamap[event[Names.eha_id]] = condition
        return condition

    def addEhaSelfLoops(self,statedecl):
        conditions = self.ehamap.values()
        rules = createRules(conditions,Target(statedecl))
        statedecl.addRules(rules)
         
    def learnlog(self,log):
        inform("learning from new log")
        self.begin()
        for event in log:
            self.next(event)
        self.end()
        #debug("learned spec:\n\n" + str(self.spec))
        return self.spec

### exact learner ###

class ExactLearner(Learner):
    def __init__(self,specification):
        self.spec = specification
        self.monitor = Monitor(specification,learning=True,dostatistics=False)

    def getSpec(self):
        return self.spec
    
    def newStateDecl(self):
        return StateDecl(self.spec.nextName(),mode=StateMode.STEP)
    
    def begin(self):
        if self.spec.getInitial() == []:
            statedecl = self.newStateDecl()
            self.spec.addStateDecl(statedecl)
            self.spec.addInitial(Target(statedecl))
        self.monitor.begin()
             
    def next(self,event):
        debug("next event: " + strEvent(event))
        pre_states = self.monitor.getStates()
        self.monitor.next(event)
        post_states = self.monitor.getStates()
        if post_states == []:
            debug("no new states ... now learning")
            inform("the following event causes learning: " + strEvent(event))
            condition = self.createCondition(event)
            targetstatedecl = self.newStateDecl()
            target = Target(targetstatedecl)
            for sourcestate in pre_states:
                sourcestatedecl = sourcestate.getStateDecl()
                rule = Rule([condition],[target])
                sourcestatedecl.addRule(rule)
                debug("adding rule " + sourcestatedecl.getName() + " :" + str(rule))
            self.monitor.addState(target.instantiate())
            self.spec.addStateDecl(targetstatedecl)

    def end(self):
        for state in self.monitor.states:
            self.spec.addSuccess(state.getStateDecl())

    def createCondition(self,event):
        kind = eventKind(event)
        if isEha(event):
            ehaid = event[Names.eha_id]
            ehadn = event[Names.eha_dn]
            constraints = {Names.eha_id : VAL(ehaid) , Names.eha_dn : VAL(ehadn)}
        if isEvr(event):
            evrid = event[Names.evr_id]
            constraints = {Names.evr_id : VAL(evrid)}
        if isDpr(event):
            dprid = event[Names.dpr_id]
            constraints = {Names.dpr_id : VAL(dprid)}
        if isCmd(event):
            cmdid = event[Names.cmd_id]
            constraints = {Names.cmd_id : VAL(cmdid)}        
        condition = Condition(kind,constraints)
        return condition
         
    def learnlog(self,log):
        inform("learning from new log")
        self.begin()
        for event in log:
            self.next(event)
        self.end()
        return self.spec


### MSL statistics ###

class Row:
    def __init__(self):
        self.sent = 0
        self.vc1_dispatched = 0
        self.vc1_validation_failed = 0
        self.completed = 0
        self.failed = 0
        self.vc0_dispatched = 0

    def incr_sent(self,count):
        self.sent = self.sent + count

    def incr_vc1_dispatched(self,count):
        self.vc1_dispatched = self.vc1_dispatched+ count
        
    def incr_vc1_validation_failed(self,count):
        self.vc1_validation_failed = self.vc1_validation_failed + count
        
    def incr_completed(self,count):
        self.completed = self.completed + count
        
    def incr_failed(self,count):
        self.failed = self.failed + count
        
    def incr_vc0_dispatched(self,count):
        self.vc0_dispatched = self.vc0_dispatched + count

class Spreadsheet:    
    def __init__(self,results,file):
        self.counts = results.getCounts() # OBJ_TYPE -> ((Field -> Value) * int)-list
        self.spreadsheet = {} # Command -> Row
        open(file,'w').write(self.getSpreadsheet())
        
    def __getRow__(self,command):
        if command in self.spreadsheet:
            row = self.spreadsheet[command]
        else:
            row = Row()
            self.spreadsheet[command] = row
        return row
    
    def __extractCounts__(self):
        for obj_type in self.counts:
            pairlist = self.counts[obj_type]
            for (dict,count) in pairlist:
                if obj_type == "COMMAND":
                    command = dict["Stem"]
                    self.__getRow__(command).incr_sent(count)
                if obj_type == "EVR" :
                    if "VC1Dispatch" in dict:
                        command = dict["VC1Dispatch"]
                        self.__getRow__(command).incr_vc1_dispatched(count)
                    if  "DispatchFailure" in dict:
                        command = dict["DispatchFailure"]
                        self.__getRow__(command).incr_vc1_validation_failed(count)
                    if "Success" in dict:
                        command = dict["Success"]
                        self.__getRow__(command).incr_completed(count)
                    if "Failure" in dict:
                        command = dict["Failure"]
                        self.__getRow__(command).incr_failed(count)
                    if "VC0Dispatch" in dict:
                        command = dict["VC0Dispatch" ]
                        self.__getRow__(command).incr_vc0_dispatched(count)

    
    def getSpreadsheet(self):
        self.__extractCounts__()
        text = "\nCommand, Sent, VC1Dispatch, Validation Failure, Completed, Failed, VC0Dispatch\n"
        for command in sorted(self.spreadsheet.keys()):
            row = self.spreadsheet[command]
            text += str(command) + ", " +  str(row.sent) + ", " + str(row.vc1_dispatched) + ", " + str(row.vc1_validation_failed) + "," 
            text += str(row.completed) + ", " + str(row.failed) + ", " + str(row.vc0_dispatched) + "\n"
        return text


### spec writer ###

class V:
    def __getattr__(self,name):
        par = PAR(name)
        return par

v = V()

def target(statewriter,actuals):
    return Target(statewriter.getStateDecl(),listify(actuals))

class SpecWriter:
    def __init__(self,name):
        self.spec = Specification(name)

    def __getattr__(self,name):
        assert name in ["error","done"]
        if name == "error":
            return self.spec.error() 
        else:
            return self.spec.done()

    def getSpec(self):
        return self.spec

    def addState(self,name,formals=[],mode=StateMode.STATE):
        statedecl = StateDecl(name,formals,mode)
        self.spec.addStateDecl(statedecl)
        return StateWriter(statedecl)

    def initial(self,statewriters):
        for target in [Target(statewriter.getStateDecl()) for statewriter in listify(statewriters)]:
            self.spec.addInitial(target)

    def forbidden(self,statewriters):
        for statedecl in [statewriter.getStateDecl() for statewriter in listify(statewriters)]:
            self.spec.addForbidden(statedecl)

    def success(self,statewriters):
        for statedecl in [statewriter.getStateDecl() for statewriter in listify(statewriters)]:
            self.spec.addSuccess(statedecl)      

    def write(self):
        self.spec.write()

class StateWriter:
    def __init__(self,statedecl):
        self.statedecl = statedecl
    
    def getStateDecl(self):
        return self.statedecl
    
    def rule(self,conditions,action,operation=None):
        self.statedecl.addRule(Rule(purifyConditions(conditions),purifyAction(action),operation))
        
def listify(x):
    if isinstance(x,list):
        return x
    else:
        return [x]

def purifyConditions(conditions):
    return listify(conditions)

def purifyAction(action):
    pureaction = []
    for x in listify(action):
        if isinstance(x,StateWriter):
            target = Target(x.getStateDecl())
        else:
            if isinstance(x,StateDecl):
                target = Target(x)
            else:
                if isinstance(x,Target):
                    target = x
                else:
                    assert False
        pureaction.append(target)
    return pureaction

def purifyConstraints(constraints):
    newconstraints = {}
    for field,constraint in constraints.iteritems():
        if  isinstance(constraint,VAL) or isinstance(constraint,IVL) or isinstance(constraint,BIT) or isinstance(constraint,PAR):
            newconstraints[field] = constraint
        else:
            newconstraints[field] =  VAL(constraint)
    return newconstraints

ALWAYS = StateMode.ALWAYS
STATE = StateMode.STATE
STEP = StateMode.STEP

def cond(name,constraints):
    pureconstraints = purifyConstraints(constraints)
    return Condition(name,pureconstraints)

def cmd(constraints):
    return cond(Names.cmd_class,constraints)
    
def evr(constraints):
    return cond(Names.evr_class,constraints)

def dpr(constraints):
    return cond(Names.dpr_class,constraints)

def eha(constraints):
    return cond(Names.eha_class,constraints)
 

### reading on log files ###

def unpickle_logfile(filename,printit=False):
    file = open(filename)
    pic = pickle.Unpickler(file)
    events = pic.load()
    out = open(filename + ".formatted",'w')
    counter = 0
    for event in events.event_list:
        counter = counter + 1
        evtxt = eventString(event,counter)
        if printit:
            print evtxt
        out.write(evtxt)
    out.close()
    return events.event_list    

def parse(file):
    data = open(file).read()
    spec = yacc.parse(data)
    return spec

### internalizing parsed specification ###

statewritermap = {}

def internalSpec(astSpec):
    monitors = []
    for astMonitor in astSpec.monitors:
        monitors.append(internalMonitor(astMonitor))
    return monitors

def internalMonitor(astMonitor):
    if isinstance(astMonitor,ast.Automaton):
        return internalAutomaton(astMonitor)
    else:
        return internalPattern(astMonitor)

def modeof(astMode):
    if astMode == "always":
        return ALWAYS
    elif astMode == "state":
        return STATE
    else:
        return STEP

def mkRange(astRange):
    if isinstance(astRange,int) or isinstance(astRange,str):
        return VAL(astRange)
    elif isinstance(astRange,ast.Interval):
        return IVL(astRange.left,astRange.right)
    elif isinstance(astRange,ast.BitValues):
        return BIT(astRange.dict)
    elif isinstance(astRange,ast.Name):
        return PAR(astRange.name)
    assert False

def mkConstraints(astConstraints):
    constraints = {}
    for astConstraint in astConstraints:
        constraints[astConstraint.name] = mkRange(astConstraint.range)
    return constraints

def mkCondition(astCondition):
    return Condition(astCondition.type,mkConstraints(astCondition.constraints))

def mkActuals(astActuals):
    actuals = []
    for astActual in astActuals:
        if isinstance(astActual,int) or isinstance(astActual,str):
            actuals.append(astActual)
        elif isinstance(astActual,ast.Name):
            actuals.append(PAR(astActual.name))
        else:
            assert False
    return actuals

def mkAction(specwriter,astAction):
    global statewritermap
    if astAction.name == "done":
        target = specwriter.done
    elif astAction.name == "error":
        target = specwriter.error
    else:
        target = statewritermap[astAction.name].getStateDecl()
    return Target(target,mkActuals(astAction.actuals))

def guardOf(astRule):
    return  [mkCondition(astCondition) for astCondition in astRule.conditions]

def actionOf(specwriter,astRule):
    return  [mkAction(specwriter,astAction) for astAction in astRule.actions]

def internalAutomaton(astAutomaton):
    global statewritermap
    specwriter = SpecWriter(astAutomaton.name)
    for astState in astAutomaton.states:
        stateWriter = specwriter.addState(astState.name, [PAR(formal) for formal in astState.formals], modeof(astState.mode))
        statewritermap[astState.name] = stateWriter
    specwriter.initial([statewritermap[astAction.name] for astAction in astAutomaton.initial])
    specwriter.forbidden([statewritermap[astName] for astName in astAutomaton.forbidden])
    specwriter.success([statewritermap[astName] for astName in astAutomaton.success])
    for astState in astAutomaton.states:
        statewriter = statewritermap[astState.name]
        for astRule in astState.rules:
            statewriter.rule(guardOf(astRule),actionOf(specwriter,astRule))
    return specwriter
            
def internalPattern(astPattern):
    astAutomaton = pattern2automaton(astPattern)
    return internalAutomaton(astAutomaton)


### translating patterns into automata ###

__statecounter__ = 0

def resetStateNames():
    global __statecounter__
    __statecounter__ = 0

def nextStateName():
    global __statecounter__
    __statecounter__ = __statecounter__ + 1
    return "S" + str(__statecounter__)

def extractVariables(event):
    variables = []
    for constraint in event.constraints:
        if isinstance(constraint.range,ast.Name):
            variables.append(constraint.range.name)
    return variables

def pattern2automaton(astPattern):
    resetStateNames()
    automaton = ast.Automaton(name=astPattern.name,states=[],initial=[],forbidden=[],success=[])
    variables = extractVariables(astPattern.event)
    names = [ast.Name(variable) for variable in variables]
    stateName1 = nextStateName()
    stateName2 = nextStateName()
    state1 = ast.State(mode="always", name=stateName1, formals=[], rules=[])
    state2 = ast.State(mode="state", name=stateName2, formals=variables, rules=[])
    automaton.states.append(state1)
    automaton.states.append(state2)
    automaton.initial.append(ast.Action(stateName1)) 
    rule = mkRule(astPattern.event,stateName2,names)
    state1.rules.append(rule)
    consequence2automaton(automaton,astPattern.consequence,variables,names,rule.actions,state2)
    return automaton

def mkRule(event,stateName,names):
    return ast.Rule([event],[ast.Action(stateName,names)])
 
def consequence2automaton(automaton,astConsequence,variables,names,actions,state):
    if isinstance(astConsequence,ast.Event):
        newStateName = nextStateName()
        newState = ast.State(mode="state", name=newStateName, formals=variables, rules=[])
        automaton.states.append(newState)
        rule = mkRule(astConsequence,newStateName,names)
        state.rules.append(rule)
        automaton.forbidden.append(state.name)
        return (rule.actions,newState)
    elif isinstance(astConsequence,ast.NegatedEvent):
        state.rules.append(mkRule(astConsequence.event,"error",[]))
        return (actions,state)
    elif isinstance(astConsequence,ast.ConsequenceSequence):
        for consequence in astConsequence.consequencelist:
            (newActions,newState) = consequence2automaton(automaton,consequence,variables,names,actions,state)
            actions = newActions
            state = newState
        return (actions,state)
    else:
        firstTime = True
        for consequence in astConsequence.consequencelist:
            if firstTime:
                (newActions,newState) = consequence2automaton(automaton,consequence,variables,names,actions,state)
                firstTime = False
            else:
                newStateName = nextStateName()
                newState = ast.State(mode="state", name=newStateName, formals=variables, rules=[])
                actions.append(ast.Action(newStateName,names))
                automaton.states.append(newState)
                (newActions,newState) = consequence2automaton(automaton,consequence,variables,names,actions,newState)
        return (newActions,newState)
        

