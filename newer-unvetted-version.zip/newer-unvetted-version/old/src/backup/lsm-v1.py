
import copy

DEBUG = False

def debug(str):
    if DEBUG:
        print "--" , str

def errormesage(str):
    print "***" , str

def min(x,y):
    if x <= y:
        return x
    else:
        return y
    
def max(x,y):
    if x >= y:
        return x
    else:
        return y

class Evr:
    def __init__(self,name,level,eventId,message,fromSse,realtime,sclk,scet,ert,module,metadata):
        self.name = name
        self.level = level
        self.eventId = eventId
        self.message = message
        self.fromSse = fromSse
        self.realtime = realtime
        self.sclk = sclk
        self.scet = scet
        self.ert = ert
        self.module = module
        self.metadata = metadata

    def __repr__(self):
        return "evr(" + self.name + "," + self.level + "," + str(self.eventId) + ")"

        # Example:
        # name="CMD_EVR_CMD_COMPLETED_SUCCESS",
        # level="COMMAND",
        # eventId=7707,
        # message="Successfully completed command CMD_NO_OP_U8 (07e1): number=5.",
        # fromSse=False,
        # realtime=True,
        # sclk="0000003411.10352",
        # scet="2000-001T12:55:46.919",
        # ert="2008-263T23:24:50.207",
        # module="cmd",
        # metadata=[('TaskName', 'cmd???'), ('SequenceId', 'RT:6011'), ('CategorySequenceId', '9')]

class ChanVal:
    def __init__(self,receiveTime,eventTime,sclk,ert,scet,channelId,type,dn,dnUnits,eu,euUnits,status,alarms):
        self.receiveTime = receiveTime
        self.eventTime = eventTime
        self.sclk = sclk
        self.ert = ert
        self.scet = scet
        self.channelId = channelId
        self.type = type
        self.dn = dn
        self.dnUnits = dnUnits
        self.eu = eu
        self.euUnits = euUnits
        self.status = status
        self.alarms = alarms
    
    def __repr__(self):
        return "chan(" + str(self.channelId) + "," + str(self.dn) + ")"

        # Example:
        # receiveTime="1221866865.0",
        # eventTime="2008-263T23:27:44.956",
        # sclk="0000004357.75001",
        # ert="2008-263T23:27:44.897",
        # scet="2000-001T13:11:33.566",
        # channelId="CMD-0001",
        # type="UNSIGNED_INT",
        # dn="8",
        # dnUnits="none",
        # eu=None,
        # euUnits="",
        # status="None",
        # alarms=[]

def isCommand(event):
    return isinstance(event,Evr) and event.level == "COMMAND"

def isChannel(event):
    return isinstance(event,ChanVal)

def isEvr(event):
    return isinstance(event,Evr)

def sameEvent(event1,event2):
    return sameChannel(event1,event2) or sameEvr(event1,event2)

def sameChannel(event1,event2):
    return isChannel(event1) and isChannel(event2) and event1.channelId == event2.channelId

def sameEvr(event1,event2):
    return isEvr(event1) and isEvr(event2) and event1.eventId == event2.eventId

def intervalize(event):
    if isChannel(event):
        specevent = copy.copy(event)
        specevent.dn = (specevent.dn,specevent.dn)
        return specevent
    else:
        return event
      
class Observation:
    def __init__(self,event):
        self.event = intervalize(event)
        self.updated = True
        self.floating = False

    def sameEvent(self,event):
        return sameEvent(self.event,event)

    def refineEvent(self,event):
        if isChannel(event):
            (low,high) = self.event.dn
            newlow = min(low,event.dn)
            newhigh = max(high,event.dn)
            self.event.dn = (newlow,newhigh)

    def matches(self,event):
        if not self.sameEvent(event):
            return False
        else:
            if isChannel(event):
                (low,high) = self.event.dn
                return low <= event.dn <= high 
            else: # an Evr
                return True
                                
    def __repr__(self):
        extra = ""
        if self.updated:
            extra += "!"
        if self.floating:
            extra +="*" 
        return str(self.event) + extra

class Obligations:
    def __init__(self):
        self.obligations = []
        self.new = True
        self.index = 0

    def empty(self):
        return self.obligations == []
    
    def addEvent(self,event):
        if self.new:
            self.add(event)
        else:
            self.refine(event)

    def add(self,event):
        for observation in self.obligations:
            if observation.sameEvent(event):
                observation.refineEvent(event)
                return
        self.obligations.append(Observation(event)) 
      
    def refine(self,event):
        index = 0
        for observation in self.obligations:
            index = index + 1
            if observation.sameEvent(event):
                observation.refineEvent(event)
                observation.updated = True
                if index <= self.index:
                    observation.floating = True
                else:
                    if not observation.floating:
                        self.index = index
                break

    def removeEvents(self):
        list = []
        for observation in self.obligations:
            if observation.updated:
                debug("keeping observation: " + str(observation))
                observation.updated = False
                list.append(observation)
            else:
                debug("ignoring observation: " + str(observation))
        self.obligations = list
        self.new = False
        self.index = 0
        debug("resulting events: " + str(list))
        debug("")

    def monitor(self,event):
        errors = []
        if self.obligations != []:
            list = []
            index = 0
            for observation in self.obligations:
                if not observation.floating:
                    index = index + 1
                if not observation.matches(event):
                    list.append(observation)
                else:
                    if index > 1:
                        warning = Warning("observation out of order " + str(observation))
                        errors += [warning]
                        print str(warning)
            self.obligations = list        
            debug("resulting obligations: " + str(self.obligations))
        return errors
  
    def __repr__(self):
        text = ""
        for observation in self.obligations:
            text += "  " + str(observation) + "\n"
        return text   
                                                            
class Specification:
    def __init__(self):
        self.map = {}
        self.current = None

    def getObligations(self,event):
        assert isCommand(event)
        key = event.eventId
        if key in self.map:
            return copy.deepcopy(self.map[key])
        else:
            return None

    def learn(self,log):
        debug("")
        debug("learning from log " + str(log))
        debug("")
        for event in log:
            debug("processing event: " + str(event))
            if isCommand(event):
                self.newCommand(event)
            else:
                self.addEvent(event)
        debug("termination of log")
        self.removeEvents() # for the last processed command
        self.current = None
                   
    def newCommand(self,event):
        assert isCommand(event)
        debug("this is a new command" )
        debug("")
        self.removeEvents() # for the previous command
        self.current = event.eventId
        if not self.current in self.map:
            self.map[self.current] = Obligations()
            
    def addEvent(self,event):
        if self.current != None:
            self.map[self.current].addEvent(event)
    
    def removeEvents(self):
        if self.current != None:
            self.map[self.current].removeEvents()
               
    def __repr__(self):
        text = "\n=== learned specification: ===\n\n"
        for key in self.map.keys():
            obligations = self.map[key]
            if not obligations.empty():
                text += "command " + str(key) + " =>\n" 
                text += str(obligations)
        return text

class Error:
    def __init__(self,message):
        self.message = message
        
    def __repr__(self):
        return "*** error " + self.message

class Warning:
    def __init__(self,message):
        self.message = message
        
    def __repr__(self):
        return "*** warning " + self.message

class Monitor:
    def __init__(self,spec):
        self.spec = spec
        self.command = None
        self.obligations = None

    def monitor(self,log):
        print ""
        print "=== monitor: ==="
        print ""
        errors = []
        self.command = None
        self.obligations = None    
        for event in log:
            errors += self.monitorEvent(event)
        errors += self.checkObligations()
        return errors
    
    def monitorEvent(self,event):
        errors = []
        debug("monitor event: " + str(event))
        if isCommand(event):
            errors += self.checkObligations() # from previous command
            self.command = event
            self.obligations = self.spec.getObligations(event)
            debug("new obligations: " + str(self.obligations))
        else:
            if self.obligations != None:
                errors += self.obligations.monitor(event)
        return errors
                        
    def checkObligations(self):
        errors = []
        if self.obligations != None and not self.obligations.empty():
            error = Error("command " + str(self.command) + " not followed by:\n" + str(self.obligations))
            errors += [error]
            print error
        self.command = None
        self.obligations = None
        return errors


###################
###  Experiment  ###
###################

def newEvr(name,level,eventId):
    return Evr(name,level,eventId,"hello there",False,True,"1","2","3","M",[])

def newChan(channelId,dn):
    return ChanVal("1","2","3","4","5",channelId,"int",dn,"none",None,"","None",[])
