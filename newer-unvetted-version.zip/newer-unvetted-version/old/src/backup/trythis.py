

m1 = {"x" : "abc", "y" : 22}
m2 = {"p" " 12.2, "q" : "MSL"}

l = [m1,m2]

class Container:
    def __init__(self,list):
        self.list = list
    
c = Container(l)

f = open("/Users/khavelun/Desktop/dump","w")
p =pickle.Pickler(f)]
p.dump(c)



l1 = [1,2,3]
l2 = [3,4,5]

def merge(formals,actuals,bindings):
    for x in range(0,len(formals)):
        print formals[x],actuals[x]
        
merge(l1,l2,{})

class V:
    def __getattr__(self,name):
        return name

v = V()

print v.x

assert False

class Condition:
    def __init__(self,kind,constraints):
        self.kind = kind
        self.constraints = constraints

    def __repr__(self):
        return self.kind + str(self.constraints)

class Constraint:
    pass

class VAL(Constraint):
    def __init__(self,value):
        self.value = value
    
    def __repr__(self):
        return str(self.value)

class IVL(Constraint):
    def __init__(self,low,high):
        self.low = low
        self.high = high

    def __repr__(self):
        return "[" + str(self.low) + ":" + str(self.high) + "]"

def cond(name,constraints):
    return Condition(name,constraints)

class State:
    def __init__(self,state,forbidden=False):
        pass
    
    def addRule(self,conditions,target):
        pass

##################################

class Specification:
    def __init__(self,name):
        self.name =  name

    def addState(self,state):
        return State(state)

    def state(self,state):
        pass
    
    def trans(self,condition,target):
        pass
    
    def forbidden(self,states):
        pass

def cmd(map):
    pass

def evr(map):
    pass
 
OK = State("Ok")
 
##### Solution 1: #####
  
s = Specification("myspec")

s.state("S")
s.trans(cond("Cmd",{"id":VAL(1)}),["W1","W2"])

s.state("W1")
s.trans(cond("Evr",{"id":VAL(1)}),["T"])

s.state("W2")
s.trans(cond("Evr",{"id":VAL(2)}),["T"])

s.state("T")

s.forbidden(["W1","W2"])

##### Solution 2: #####

s = Specification("myspec")

s.state("S")
s.trans(cmd({"id":1}),["W1","W2"])

s.state("W1")
s.trans(evr({"id":1}),["T"])

s.state("W2")
s.trans(evr({"id":2}),["T"])

s.forbidden(["W1","W2"])


##### Solution 3: #####

s = Specification("myspec")

S = State("S") 
W1 = State("W1",forbidden=True) 
W2 = State("W2",forbidden=True)
T = State("T")

s.addState(S)
s.addState(W1)
s.addState(W2)
s.addState(T)

S.addRule(cmd({"id":1}),[W1,W2])
W1.addRule(evr({"id":1}),T)
W2.addRule(evr({"id":2}),T)

s.forbidden(["W1","W2"])

##### Solution 4: #####

s = Specification("myspec")

S = s.addState("S") 
W1 = s.addState("W1",forbidden=True) 
W2 = s.addState("W2",forbidden=True)
T = s.addState("T")

S.addRule(cmd({"id":1}),[W1,W2])
W1.addRule(evr({"id":1}),T)
W2.addRule(evr({"id":2}),T)
        
# Patterns

class Pattern:
    pass

class Response(Pattern):
    def __init__(self,req,resp):
        self.req = req
        self.resp = resp

t = Response("otherspec",
             [
              [cond("Evr",{"a":VAL(1)})],
              [cond("Evr",{"a":VAL(1)})],
               [
                cond("Evr",{"a":VAL(1)}),
                cond("Evr",{"a":VAL(1)}),
                ]
               ]
        )

# This could work.

#look:DRILL_DMP\
#    evr(CMD_EVR_VC1_CMD_DISPATCH,positive)\
#    evr(CMD_EVR_CMD_COMPLETED_SUCCCESS,positive)\
#    evr(CMD_EVR_CMD_COMPLETED_FAILURE,negative)\
#    chan(id:CMD-0004,positive,0x03e0,contains the opcode of the last immediate command dispatched)\
#    chan(id:CMD-0007,positive)\
#    chan(id:CMD-0001,negative)\
#    chan(id:CMD-0009,negative)\
#    prod(name:DrillAllParms,1,*)



