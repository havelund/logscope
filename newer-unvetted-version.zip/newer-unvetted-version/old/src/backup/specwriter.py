
from lsm import *
import pickle
import event_list

class V:
    def __getattr__(self,name):
        par = PAR(name)
        return par

v = V()

def target(statewriter,actuals):
    return Target(statewriter.getStateDecl(),listify(actuals))

class SpecWriter:
    def __init__(self,name):
        self.spec = Specification(name)

    def __getattr__(self,name):
        assert name in ["error","done"]
        if name == "error":
            return self.spec.error() 
        else:
            return self.spec.done()

    def getSpec(self):
        return self.spec

    def addState(self,name,formals=[],mode=StateMode.STATE):
        statedecl = StateDecl(name,formals,mode)
        self.spec.addStateDecl(statedecl)
        return StateWriter(statedecl)

    def initial(self,statewriters):
        for target in [Target(statewriter.getStateDecl()) for statewriter in listify(statewriters)]:
            self.spec.addInitial(target)

    def forbidden(self,statewriters):
        for statedecl in [statewriter.getStateDecl() for statewriter in listify(statewriters)]:
            self.spec.addForbidden(statedecl)

    def success(self,statewriters):
        for statedecl in [statewriter.getStateDecl() for statewriter in listify(statewriters)]:
            self.spec.addSuccess(statedecl)      

    def write(self):
        self.spec.write()

class StateWriter:
    def __init__(self,statedecl):
        self.statedecl = statedecl
    
    def getStateDecl(self):
        return self.statedecl
    
    def rule(self,conditions,action,operation=None):
        self.statedecl.addRule(Rule(purifyConditions(conditions),purifyAction(action),operation))
        
def listify(x):
    if isinstance(x,list):
        return x
    else:
        return [x]

def purifyConditions(conditions):
    return listify(conditions)

def purifyAction(action):
    pureaction = []
    for x in listify(action):
        if isinstance(x,StateWriter):
            target = Target(x.getStateDecl())
        else:
            if isinstance(x,StateDecl):
                target = Target(x)
            else:
                if isinstance(x,Target):
                    target = x
                else:
                    assert False
        pureaction.append(target)
    return pureaction

def purifyConstraints(constraints):
    newconstraints = {}
    for field,constraint in constraints.iteritems():
        if  isinstance(constraint,VAL) or isinstance(constraint,IVL) or isinstance(constraint,PAR):
            newconstraints[field] = constraint
        else:
            newconstraints[field] =  VAL(constraint)
    return newconstraints

ALWAYS = StateMode.ALWAYS
STATE = StateMode.STATE
STEP = StateMode.STEP

def cond(name,constraints):
    pureconstraints = purifyConstraints(constraints)
    return Condition(name,pureconstraints)

def cmd(constraints):
    return cond(Names.cmd_class,constraints)
    
def evr(constraints):
    return cond(Names.evr_class,constraints)

def dpr(constraints):
    return cond(Names.dpr_class,constraints)

def eha(constraints):
    return cond(Names.eha_class,constraints)
 

### reading on log files ###

def unpickle_logfile(filename,printit=False):
    file = open(filename)
    pic = pickle.Unpickler(file)
    events = pic.load()
    out = open(filename + ".formatted",'w')
    counter = 0
    for event in events.event_list:
        counter = counter + 1
        evtxt = eventString(event,counter)
        if printit:
            print evtxt
        out.write(evtxt)
    out.close()
    return events.event_list
    