

from lsm.lsm import *
 
import unittest
  
class TestParser(unittest.TestCase):

    def test1(self):
           
        specs = parse("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec3")
        print str(specs)

        ispecs = internalSpec(specs)
        
        print "number of specs : " , len(ispecs)
        for ispec in ispecs:
            ispec.write()
        
        events = unpickle_logfile("/Users/khavelun/Desktop/MSLPICKLE/pickled_events.pic")
        print "number of events :" , len(events)

        obs = Observer(ispecs)
        obs.monitor(events)

        #ispec = ispecs[0]
        #mon = Monitor(ispec)
        #mon.monitor(events)
        #Spreadsheet(mon,"/Users/khavelun/Desktop/MSLPICKLE/spreadsheet.txt")

        
if __name__ == '__main__':
    unittest.main()
