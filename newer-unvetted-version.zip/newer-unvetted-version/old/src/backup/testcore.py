
from eventdefs import *
from lsm.lsm import *
import unittest

class TestCore(unittest.TestCase):
    def setUp(self):
        pass

    def test1(self):
        c1 = newCmd(1)
        c2 = newCmd(2)
        c3 = newCmd(3)

        e1 = newEvr(1)
        e2 = newEvr(2)
        e3 = newEvr(3)
    
        d1 = newDpr(1)
        d2 = newDpr(2)
        d3 = newDpr(3)
    
        a1 = newEha(1,1)
        a2 = newEha(1,2)  
        a3 = newEha(1,3)
        a4 = newEha(1,4)

        log1 = [c1,e1,d1,c2,a1,a2,e3]
        log2 = [c1,d1,e1,c2,e3,a3]
        log3 = [c1,e1,e2,c2,a3,d2]
 
        log4 = [c1,e2,e1,c2]
        log5 = [c1,e1,e2,c2,a1,a2,e3,a3,a4]

        spec = Specification("LogPattern")

        learner = ExactLearner(spec)
        learner.learnlog(log1)
        learner.learnlog(log2)
        learner.learnlog(log3)

        inform("\nfinal specification:\n" + str(spec))
        spec.dumpDot()

        mon = Monitor(spec)
        mon.monitor(log1)
        mon.monitor(log2)
        mon.monitor(log3)
        mon.monitor(log4)
        mon.monitor(log5)
 
 
if __name__ == '__main__':
    unittest.main()


