
from eventdefs import *
from lsm.specwriter import *
import unittest

### specification ###

class TestSpecLanguage(unittest.TestCase):
    def setUp(self):
        self.c1 = newCmd(1)
        self.c2 = newCmd(2)
        self.e1 = newEvr(1)
        self.e2 = newEvr(2)
        self.e3 = newEvr(3)
        self.e4 = newEvr(4)

    def test1(self):
        ### specfication ###
            
        s = SpecWriter("myspec")

        S1 = s.addState("S1",mode=ALWAYS) 
        S2 = s.addState("S2") 
        S3 = s.addState("S3")   
        S4 = s.addState("S4",mode=STEP)
        S5 = s.addState("S5")

        s.initial(S1)
        s.forbidden([S3,S5])

        S1.rule(cmd({"id":1}),S2)
        S2.rule(cmd({"id":2}),[S3,S5])
        S3.rule(evr({"eventId":1}),S4)
        S4.rule(evr({"eventId":2}),s.done)
        S5.rule(evr({"eventId":3}),s.done)
        S5.rule(evr({"eventId":4}),s.error)

        s.write()

        ### monitoring ###

        mon = Monitor(s)

        log1 = [self.c1,self.c2,self.e1,self.e3,self.e2]
        mon.monitor(log1)

        log2 = [self.c2,self.c1,self.e1,self.e2,self.e4]
        mon.monitor(log2)

    def test2(self):

        log1 = [self.c1,self.c2,self.e1,self.e3,self.e2]
        log2 = [self.c2,self.c1,self.e1,self.e2,self.e4]
        
        ### learning ###

        spec = Specification("LogPattern")

        learner = ExactLearner(spec)
        learner.learnlog(log1)
        learner.learnlog(log2)

        spec.write()

        mon = Monitor(spec)
        mon.monitor(log1)
        mon.monitor(log2) 
 
if __name__ == '__main__':
    unittest.main()
