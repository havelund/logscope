
import string

### Options ###

class Options:
    dotfile = "/Users/khavelun/Desktop/MSLDOT"
    debug = False
    inform = True

class Names:
    cmd_class = "Cmd"
    evr_class = "Evr"
    eha_class = "Eha"
    dpr_class = "Dpr"
    cmd_id = "id"
    dpr_id = "id"
    evr_id = "eventId"
    eha_id = "channelId"
    eha_dn = "dn"
    cmd_scet = "scet"
    evr_scet = "scet"
    eha_scet = "scet"
    dpr_scet = "scet"


### events ###

def strCmd(cmd):
    cmdid = getattr(cmd,Names.cmd_id)
    return "cmd(" + str(cmdid) + ")"

def strDpr(dpr):
    dprid = getattr(dpr,Names.dpr_id)
    return "dpr(" + str(dprid) + ")"

def strEvr(evr):
    evrid = getattr(evr,Names.evr_id)
    return "evr(" + str(evrid) + ")"

def strEha(eha):
    ehaid = getattr(eha,Names.eha_id)
    ehadn = getattr(eha,Names.eha_dn)
    return "chan(" + str(ehaid) + "," + str(ehadn) + ")"
        
def strEvent(event):
    if isCmd(event):
        return strCmd(event)
    if isDpr(event):
        return strDpr(event)
    if isEvr(event):
        return strEvr(event)
    if isEha(event):
        return strEha(event)
    print str(event)
    assert False

def isCmd(event):
    return classNameOf(event) == Names.cmd_class

def isEvr(event):
    return classNameOf(event) == Names.evr_class

def isDpr(event):
    return classNameOf(event) == Names.dpr_class

def isEha(event):
    return classNameOf(event) == Names.eha_class

def sameCmd(cmd1,cmd2):
    cmd1id = getattr(cmd1,Names.cmd_id)
    cmd2id = getattr(cmd2,Names.cmd_id)
    return isCmd(cmd1) and isCmd(cmd2) and cmd1id == cmd2id

def sameEvr(event1,event2):
    event1id = getattr(event1,Names.evr_id)
    event2id = getattr(event2,Names.evr_id)
    return isEvr(event1) and isEvr(event2) and event1id == event2id

def sameDpr(event1,event2):
    event1id = getattr(event1,Names.dpr_id)
    event2id = getattr(event2,Names.dpr_id)
    return isDpr(event1) and isDpr(event2) and event1id == event2id

def sameEha(event1,event2):
    event1id = getattr(event1,Names.eha_id)
    event2id = getattr(event2,Names.eha_id) 
    return isEha(event1) and isEha(event2) and event1id == event2id

def getChannelId(event):
    assert isEha(event)
    return getattr(event,Names.eha_id)

def getScet(event):
    if isCmd(event):
        return getattr(event,Names.cmd_scet)
    if isEvr(event):
        return getattr(event,Names.evr_scet)
    if isEha(event):
        return getattr(event,Names.eha_scet)
    if isDpr(event):
        return getattr(event,Names.dpr_scet)
    assert False # we should not reach this point

def compare(event1,event2):
    scet1 = getScet(event1)
    scet2 = getScet(event2)
    if scet1 < scet2:
        return -1
    if scet1 == scet2:
        return 0
    if scet1 > scet2:
        return 1  


### auxiliary functions and classes ###

def debug(str):
    if Options.debug:
        print "--" , str

def inform(str):
    if Options.inform:
        print "--" , str 

def dump(str):
    print str

def min(x,y):
    if x <= y:
        return x
    else:
        return y
    
def max(x,y):
    if x >= y:
        return x
    else:
        return y

def exists(list1,list2):
    for element in list1:
        if element in list2:
            return True
    return False
          
def createRules(conditions,target):
    rules = []
    for condition in conditions:    
        rules.append(Rule([condition],[target]))
    return rules

def classNameOf(event):
    return event.__class__.__name__

def startswith(str1,str2):
    return string.count(str1,str2,0,len(str2)) > 0

def containsError(states):
    for state in states:
        if state.isErrorState():
            return True
    return False

def list2text(list,sep=","):
    text = ""
    separator = False
    for element in list:
        if separator:
            text += sep
        else:
            separator = True
        text += str(element)
    return text

def listonlines(list):
    text = ""
    for e in list:
        text += "\n" + str(e) + "\n"
    text += "\n"
    return text
            
def sort(listoflists):
    onelist = []
    for list in listoflists:
        onelist += list
    return sorted(onelist,compare)   

def aFuture(states):
    for state in states:
        if not state.isErrorState():
            return True
    return False

class Error:
    def __init__(self,location,message):
        self.location = location
        self.message = message
        
    def __repr__(self):
        return "*** " + str(self.location) + " : " + self.message


### states ###

class StateMode:
    STEP = 1
    STATE = 2
    ALWAYS = 3

class StateDecl:
    def __init__(self,name,formals=[],mode=StateMode.STATE):
        self.name = name
        if isinstance(formals,list):
            self.formals = formals
        else: # one argument
            self.formals = [formals]
        self.mode = mode
        self.rules = []

    def getFullName(self):
        return self.name

    def getName(self):
        if startswith(self.name,"error"):
            return "error"
        if startswith(self.name,"done"):
            return"done"
        return self.name

    def getFormals(self):
        return self.formals

    def addRule(self,rule):
        self.rules.append(rule)

    def addRules(self,rules):
        for rule in rules:
            self.addRule(rule)

    def getRules(self):
        return self.rules

    def getMode(self):
        return self.mode

    def isErrorState(self):
        return self.getName() == "error"

    def isDoneState(self):
        return self.getName() == "done"

    def shortRepr(self):
        text = self.getName() 
        if self.formals != []:
            text += "(" + list2text(self.formals) + ")"   
        return text

    def __repr__(self):
        if self.mode == StateMode.STEP:
            mode = " step "
        else:
            if self.mode == StateMode.STATE:
                mode = " state "
            else:
                mode = " always "
        text = mode + self.name 
        if self.formals != []:
            text += "(" + list2text(self.formals) + ")"   
        text += " {"
        if self.rules == []:
            text += "}"
        else:
            text += "\n"
            for rule in self.rules:
                text += str(rule) + "\n"
            text += "  }"
        return text
          
class Rule:
    def __init__(self,guard,action,operation=None):
        self.guard = guard
        self.action = action
        self.operation = operation

    def getGuard(self):
        return self.guard
    
    def getAction(self):
        return self.action

    def operation(self,event):
        if self.operation != None:
            self.operation(event)

    def __repr__(self):
        text = "    "
        text += list2text(self.guard)
        text += " => "
        text += list2text(self.action)
        return text   

class Condition:
    def __init__(self,kind,constraints):
        self.kind = kind
        self.constraints = constraints

    def thisKind(self,event):
        return classNameOf(event) == self.kind
           
    def matchesField(self,event,field):
        return self.thisKind(event) and ((not field in self.constraints) or (self.constraints[field].matches(getattr(event,field),{})))
                
    def matches(self,event,binding):
        if not self.thisKind(event):
            return None
        accumbinding = {}
        for field,constraint in self.constraints.iteritems():
            debug("checking constraint " + str(field) + " : " + str(constraint) + " in binding " + str(binding))
            localbinding = constraint.matches(getattr(event,field),binding)
            if localbinding == None:
                return None
            accumbinding.update(localbinding)
        return accumbinding

    def widen(self,field,value):
        assert field in self.constraints
        constraint = self.constraints[field]
        assert isinstance(constraint,IVL)
        constraint.widen(value)

    def __repr__(self):
        return self.kind + str(self.constraints)

class VAL:
    def __init__(self,value):
        self.value = value
    
    def matches(self,value,binding):
        if value == self.value:
            return {}
        else:
            return None

    def __repr__(self):
        return str(self.value)

class IVL:
    def __init__(self,low,high):
        self.low = low
        self.high = high
        
    def matches(self,value,binding):
        if self.low <= value <= self.high:
            return {}
        else:
            return None
    
    def widen(self,value):
        self.low = min(self.low,value)
        self.high  = max(self.high,value)

    def __repr__(self):
        return "[" + str(self.low) + ":" + str(self.high) + "]"

class PAR:
    def __init__(self,name):
        self.name = name

    def getName(self):
        return self.name

    def matches(self,value,bindings):
        debug("matching " + str(value) + " against name " + self.name + " with binding " + str(bindings))
        if self.name in bindings:
            if value == bindings[self.name]:
                return {}
            else:
                return None
        else:
            return {self.name : value}

    def __repr__(self):
        prefix = ""
        return prefix + self.name

class Target:
    def __init__(self,statedecl,actuals=[]):
        self.statedecl = statedecl
        self.actuals = actuals

    def getStateDecl(self):
        return self.statedecl

    def instantiate(self,bindings={}):
        localbindings = self.instantiateBindings(self.statedecl.getFormals(),self.actuals,bindings)      
        return State(self.statedecl,localbindings)

    def instantiateBindings(self,formals,actuals,bindings):
        assert len(formals) == len(actuals)
        localbindings = {}
        for index in range(0,len(formals)):
            formal = formals[index] # PAR("x") 
            actual = actuals[index]   # either a PAR("y") or a normal value
            if isinstance(actual,PAR):
                actualname = actual.getName()
                assert actualname in bindings
                localbindings[formal.getName()] = bindings[actualname]
            else:
                localbindings[formal.getName()] = actual
        return localbindings

    def __repr__(self):
        text = self.statedecl.getName()
        if self.actuals != []:
            text += "("  + list2text(self.actuals) + ")"
        return text      
        
        
### specification ###

class StateKind:
    INITIAL = 1
    NORMAL = 2
    SUCCESS = 3
    FORBIDDEN = 4
    ERROR = 5
    DONE = 6

class NameGenerator:
    def __init__(self,stem,number):
        self.stem = stem
        self.number = number
                        
    def next(self):
        self.number = self.number + 1
        return self.stem + str(self.number)

class Specification:
    def __init__(self,name):
        self.name = name
        self.statedecls = []
        self.initial = []
        self.forbidden = []
        self.success = []
        self.stategenerator = NameGenerator("S",0)
        self.errorgenetor = NameGenerator("error",0)
        self.donegenerator = NameGenerator("done",0)

    def getName(self):
        return self.name

    def addStateDecl(self,statedecl):
        self.statedecls.append(statedecl)
    
    def addInitial(self,target):
        self.initial.append(target)
    
    def getInitial(self):
        return self.initial
        
    def addForbidden(self,statedecl):
        self.forbidden.append(statedecl)
    
    def getForbidden(self):
        return self.forbidden
        
    def addSuccess(self,statedecl):
        self.success.append(statedecl)
                       
    def getSuccess(self):
        return self.success
                       
    def nextName(self):
        return self.stategenerator.next()                       
        
    def error(self):
        errorStateDecl = StateDecl(self.errorgenetor.next(),mode=StateMode.STEP)
        self.addStateDecl(errorStateDecl)
        return errorStateDecl
                       
    def done(self):
        doneStateDecl = StateDecl(self.donegenerator.next(),mode=StateMode.STEP)
        self.addStateDecl(doneStateDecl)
        return doneStateDecl
                       
    def wellformed(self):
        return True
                                              
    def __repr__(self):
        text = "specification " + self.name + " {\n"
        for statedecl in self.statedecls:
            if not statedecl.isErrorState() and not statedecl.isDoneState():
                text += str(statedecl) + "\n\n"
        text += "  initial "
        for init in self.initial:
            text += str(init) + " "
        text += "\n"
        if self.forbidden != []:
            text +=  "  forbidden "
            for forbid in self.forbidden:
                text += forbid.getName() + " "
            text += "\n"
        if self.success != []:
            text +=  "  success "
            for success in self.success:
                text += success.getName() + " "
            text += "\n"
        text += "}"
        return text

    def write(self):
        print str(self)
        self.dumpDot()

    def nodeDecl(self,statedecl):    
        kind = self.getKind(statedecl)
        mode = statedecl.getMode()
        modetxt = ""
        if mode == StateMode.ALWAYS:
            modetxt = "@ "
        if mode == StateMode.STEP:
            modetxt = "# "
        format = "label=\"" + modetxt + statedecl.shortRepr() + "\""
        if kind == StateKind.INITIAL:
            format += ",style=filled,color=lightgrey"
        if kind == StateKind.NORMAL:
            pass
        if kind == StateKind.SUCCESS:
            format += ",shape=doublecircle"
        if kind == StateKind.FORBIDDEN:
            format += ",shape=invhouse"
        if kind == StateKind.ERROR:
            format += ",style=filled,color=black,fontcolor=white"
        if kind == StateKind.DONE:
            pass
        decl = "node_" + statedecl.getFullName() + "[" + format + "];"
        return decl
    
    def getKind(self,statedecl):
        if statedecl in [target.getStateDecl() for target in self.initial]:
            return StateKind.INITIAL
        if statedecl in self.success:
            return StateKind.SUCCESS
        if statedecl in self.forbidden:
            return StateKind.FORBIDDEN
        if statedecl.isErrorState():
            return StateKind.ERROR
        if statedecl.isDoneState():
            return StateKind.DONE
        return StateKind.NORMAL

    def dumpDot(self):
        dot = open(Options.dotfile + "/" + self.name + ".dot",'w')
        dot.write("digraph states {\n")
        dot.write("node [shape = circle];\n")
        for statedecl in self.statedecls:
            dot.write("    " + self.nodeDecl(statedecl) + "\n")
        for statedecl in self.statedecls:
            sourcenode = "node_" + statedecl.getFullName()
            for rule in statedecl.getRules():
                guard = list2text(rule.getGuard())
                label = "[label=\"" + guard + "\"]"
                for target in rule.getAction():
                    targetnode = "node_" + target.getStateDecl().getFullName()
                    dot.write("    " + sourcenode + " -> " + targetnode + label + ";\n")
        dot.write("}\n");


### monitor ###

class State:
    def __init__(self,statedecl,bindings):
        self.statedecl = statedecl
        self.bindings = bindings

    def getStateDecl(self):
        return self.statedecl

    def getBindings(self):
        return self.bindings

    def isErrorState(self):
        return self.statedecl.isErrorState()
    
    def __repr__(self):
        return str(self.statedecl) + "\n  with bindings: " + str(self.bindings)
    
    def shortRepr(self):
        return self.statedecl.shortRepr() + " with bindings: " + str(self.bindings)
    
class Monitor:
    def __init__(self,specification,learning=False):
        if isinstance(specification,Specification):
            self.specification = specification
        else:
            self.specification = specification.getSpec()
        assert self.specification.wellformed()
        self.observations = []
        self.states = specification.initial
        self.learning = learning
        self.error = False
        
    def addObservation(self,obs):
        self.observations.append(obs)

    def getEvent(self):
        return self.observations[0] # assuming there is only one

    def addState(self,state):
        self.states.append(state)

    def getStates(self):
        return self.states

    def trueCondition(self,condition,binding):
        for observation in self.observations:
            debug("examining observation: " + strEvent(observation))
            newbinding = condition.matches(observation,binding)
            if newbinding != None:
                return newbinding
        return None
        
    def trueGuard(self,guard,binding):  
        accumbinding = {}
        for condition in guard:
            debug("testing condition " + str(condition))
            localbinding = self.trueCondition(condition,binding)
            if localbinding == None:
                debug("condition is false")
                return None
            debug("generating binding: " + str(localbinding))
            accumbinding.update(localbinding)
            debug("condition is true")
        return accumbinding

    def apply(self):
        errors = []
        states = []
        for state in self.states:
            debug("checking state : " + state.shortRepr())
            statedecl = state.getStateDecl()
            fired = False
            for rule in statedecl.getRules():
                debug("testing rule: " + str(rule))
                localbindings = self.trueGuard(rule.getGuard(),state.getBindings()) 
                if localbindings != None:
                    debug("guard satisfied, adding actions") 
                    bindings = state.getBindings().copy()
                    bindings.update(localbindings)
                    newstates = [target.instantiate(bindings) for target in rule.getAction()]
                    states += newstates
                    fired = True
                    rule.operation(self.getEvent())
                    if containsError(newstates):
                        location = self.specification.getName()
                        error = Error(location,"error state entered")
                        errors += [error]
                        self.errormsg(str(error))
                        #self.error = True 
            if statedecl.mode == StateMode.ALWAYS or ((not fired) and statedecl.mode == StateMode.STATE):
                states += [state]
        self.states = states
        self.observations = []
        debug("---> new set of states: \n" + listonlines(self.states))
        if self.states == [] and self.specification.getSuccess() != []:
            location = self.specification.getName()
            error = Error(location,"monitoring terminates in non-success state")
            errors += [error]
            self.errormsg(str(error))
            #self.error = True
        self.error = not aFuture(self.states)
        return errors

    def begin(self):
        self.error = False
        self.observations = []
        self.states = [target.instantiate() for target in self.specification.getInitial()]

    def next(self,event):
        debug("checking automaton: " + self.specification.getName())
        if self.learning or not self.error:
            self.observations = [event]
            return self.apply()
        else:
            return []

    def end(self):
        location = self.specification.getName() + " end"
        errors = []
        if self.specification.forbidden != []:
            forbidden = [state for state in self.states if state.getStateDecl() in self.specification.forbidden]
            if forbidden != []:
                error = Error(location,"forbidden states: " + str([state.shortRepr() for state in forbidden]))
                errors += [error]
                self.errormsg(str(error))
        if self.specification.success != []:
            if not exists(self.specification.success,[state.getStateDecl() for state in self.states]):
                error = Error(location,"none of the success states have been reached")
                errors += [error]
                self.errormsg(str(error))
        return errors

    def monitor(self,log):
        print "\n===== monitoring new log: =====\n"
        errors = []
        self.begin()
        for event in log:
            inform(">>> next event: " + strEvent(event))
            errors += self.next(event)
        errors += self.end()
        return errors

    def errormsg(self,str):
        if not self.learning:
            print str


### observer ###

class Observer:
    def __init__(self,requirements=[]):
        self.monitors = []
        for req in requirements:
            if isinstance(req,Monitor):
                self.monitors.append(req)
            else:
                monitor = Monitor(req)
                self.monitors.append(monitor)

    def addMonitor(self,monitor):
        self.monitors.appened(monitor)
        
    def addSpec(self,specification):
        monitor = Monitor(specification)
        self.monitors.append(monitor)    

    def begin(self):
        for monitor in self.monitors:
            monitor.begin()

    def next(self,event):
        errors = []
        for monitor in self.monitors:
            errors += monitor.next(event)
        return errors

    def end(self):
        errors = []
        for monitor in self.monitors:
            errors += monitor.end()
        return errors

    def monitor(self,log):
        print "\n===== monitoring new log: =====\n"
        errors = []
        self.begin()
        for event in log:
            inform(">>> next event: " + strEvent(event))
            errors += self.next(event)
        errors += self.end()
        return errors


### learner ###

class Learner:
    pass

class ExactLearner(Learner):
    def __init__(self,specification):
        self.spec = specification
        self.monitor = Monitor(specification,learning=True)
        self.ehamap = {} # EhaId -m-> Condition

    def getSpec(self):
        return self.spec
    
    def newStateDecl(self):
        return StateDecl(self.spec.nextName(),mode=StateMode.STEP)
    
    def begin(self):
        if self.spec.getInitial() == []:
            statedecl = self.newStateDecl()
            self.spec.addStateDecl(statedecl)
            self.spec.addInitial(Target(statedecl))
        self.monitor.begin()
        self.ehamap = {}
             
    def next(self,event):
        debug("next event: " + strEvent(event))
        if isEha(event) and not self.existingEhaEvent(event):            
            debug("this is an eha not in the eha map")
            condition = self.ehaOfRules(event)
            if condition != None:
                debug("refilling eha map with: " + str(condition))
                self.ehamap[getChannelId(event)] = condition
        if self.existingEhaEvent(event):
            debug("an existing EHA event, refine")
            self.refineEhaEvent(event)
            debug("refined condition: " + str(self.ehamap[getChannelId(event)]))
        pre_states = self.monitor.getStates()
        self.monitor.next(event)
        post_states = self.monitor.getStates()
        if post_states == []:
            debug("no new states ... now learning")
            inform("the following event causes learning: " + strEvent(event))
            condition = self.createCondition(event)
            targetstatedecl = self.newStateDecl()
            self.addEhaSelfLoops(targetstatedecl)
            target = Target(targetstatedecl)
            for sourcestate in pre_states:
                sourcestatedecl = sourcestate.getStateDecl()
                rule = Rule([condition],[target])
                sourcestatedecl.addRule(rule)
                debug("adding rule " + sourcestatedecl.getName() + " :" + str(rule))
            self.monitor.addState(target.instantiate())
            self.spec.addStateDecl(targetstatedecl)

    def end(self):
        for state in self.monitor.states:
            self.spec.addSuccess(state.getStateDecl())

    def ehaOfRules(self,event):
        for state in self.monitor.getStates():
            for rule in state.getStateDecl().getRules():
                for condition in rule.getGuard():
                    if condition.matchesField(event,Names.eha_id):
                        return condition
        debug("did not find any rule with that eha condition")
        return None

    def existingEhaEvent(self,event):
        return isEha(event) and getChannelId(event) in self.ehamap 

    def refineEhaEvent(self,event):
        assert isEha(event) and getChannelId(event) in self.ehamap
        condition = self.ehamap[getChannelId(event)]
        eventdn = getattr(event,Names.eha_dn)
        condition.widen(Names.eha_dn,eventdn)

    def createCondition(self,event):
        kind = classNameOf(event)
        if isEha(event):
            ehaid = getattr(event,Names.eha_id)
            ehadn = getattr(event,Names.eha_dn)
            constraints = {Names.eha_id : VAL(ehaid) , Names.eha_dn : IVL(ehadn,ehadn)}
        if isEvr(event):
            evrid = getattr(event,Names.evr_id)
            constraints = {Names.evr_id : VAL(evrid)}
        if isDpr(event):
            dprid = getattr(event,Names.dpr_id)
            constraints = {Names.dpr_id : VAL(dprid)}
        if isCmd(event):
            cmdid = getattr(event,Names.cmd_id)
            constraints = {Names.cmd_id : VAL(cmdid)}        
        condition = Condition(kind,constraints)
        if isEha(event):
            self.ehamap[event.channelId] = condition
        return condition

    def addEhaSelfLoops(self,statedecl):
        conditions = self.ehamap.values()
        rules = createRules(conditions,Target(statedecl))
        statedecl.addRules(rules)
         
    def learnlog(self,log):
        inform("learning from new log")
        self.begin()
        for event in log:
            self.next(event)
        self.end()
        #debug("learned spec:\n\n" + str(self.spec))
        return self.spec

