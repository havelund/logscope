
from testcore import *
from testspeclang import *
from testobserver import *
from testparameters import *
from testcommands import *

load = unittest.TestLoader().loadTestsFromTestCase
 
suite1 = unittest.TestSuite(
                            [
                             load(TestCore),
                             load(TestSpecLanguage),
                             load(TestObserver),
                             load(TestParameters),
                             load(TestCommands)
                             ]
                            )

unittest.TextTestRunner(verbosity=2).run(suite1)

