
from lsm import *

class Patterns:
    def __init__(self,patterns):
        self.patterns = patterns
        
    def addPattern(self,pattern):
        self.patterns.append(pattern)    
    
class Pattern:
    def __init__(self,trigger,consequence):
        self.trigger = trigger
        self.consequence = consequence

class Flow:
    pass

class CondSeq(Flow):
    def __init__(self,sequence):
        self.sequence = sequence

class CondSet(Flow):
    def __init__(self,sequence):
        self.sequence = sequence        
        
        
class PatternWriter:
    def __init__(self,name):
        self.spec = Specification(name)

    def getSpec(self):
        return self.spec

    