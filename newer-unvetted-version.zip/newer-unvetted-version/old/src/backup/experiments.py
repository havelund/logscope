
DEBUG = True

def debug(str):
    if DEBUG:
        print "--" , str

def errormsg(str):
    print "***" , str

def min(x,y):
    if x <= y:
        return x
    else:
        return y
    
def max(x,y):
    if x >= y:
        return x
    else:
        return y

def exists(list1,list2):
    for element in list1:
        if element in list2:
            return True
    return False

class Cmd:
    def __init__(self,x):
        self.x = x
    def __eq__(self,other):
        return self.x == other.x
    
    def __repr__(self):
        return "cmd(" + str(self.x) + ")"
        
class Evr:
    def __init__(self,x):
        self.x = x

    def __eq__(self,other):
        return self.x == other.x
    
    def __repr__(self):
        return "evr(" + str(self.x) + ")"     
          
class Rule:
    def __init__(self,condition,action):
        self.condition = condition
        self.action = action

    def __repr__(self):
        text = "    "
        for cond in self.condition:
            text += str(cond)
        text += " => "
        for state  in self.action:
            text += state.name 
        return text   

class State:
    def __init__(self,name):
        self.name = name
        self.rules = []

    def addRule(self,rule):
        self.rules.append(rule)

    def __repr__(self):
        text = "  state " + self.name + " {"
        if self.rules == []:
            text += "}"
        else:
            text += "\n"
            for rule in self.rules:
                text += str(rule) + "\n"
            text += "  }"
        return text

class NameGenerator:
    def __init__(self,stem):
        self.stem = stem
        self.number = 0
        
    def next(self):
        self.number = self.number + 1
        return self.stem + str(self.number)

class Specification:
    def __init__(self,name):
        self.name = name
        self.states = []
        self.initial = []
        self.forbidden = []
        self.success = []

    def addState(self,state):
        self.states.append(state)
    
    def addInitial(self,state):
        self.initial.append(state)
        
    def addForbidden(self,state):
        self.forbidden.append(state)
    
    def getInitial(self):
        return self.initial
    
    def addSuccess(self,state):
        self.success.append(state)
                       
    def __repr__(self):
        text = "specification " + self.name + " {\n"
        for state in self.states:
            text += str(state) + "\n\n"
        text += "  initial "
        for init in self.initial:
            text += init.name + " "
        text += "\n"
        if self.forbidden != []:
            text +=  "  forbidden "
            for forbid in self.forbidden:
                text += forbid.name + " "
            text += "\n"
        if self.success != []:
            text +=  "  success "
            for success in self.success:
                text += success.name + " "
            text += "\n"
        text += "}"
        return text

    def write(self):
        print str(self)
    
class Monitor:
    def __init__(self,specification):
        self.specification = specification
        self.observations = []
        self.states = specification.initial
        
    def addObservation(self,obs):
        self.observations.append(obs)

    def addState(self,state):
        self.states.append(state)

    def getStates(self):
        return self.states

    def truecond(self,condition):
        for c in condition:
            if not c in self.observations:
                return False
        return True
    
    def apply(self):
        states = []
        for state in self.states:
            for rule in state.rules:
                if self.truecond(rule.condition):
                    print "condition satisfied" , rule.condition 
                    states += rule.action
        self.states = states
        self.observations = []

    def monitor(self,log):
        print "\nmonitoring new log:\n"
        self.begin()
        for event in log:
            self.next(event)
        self.end()

    def begin(self):
        self.observations = []
        self.states = self.specification.initial

    def next(self,event):
        self.observations = [event]
        self.apply()

    def end(self):
        assert self.specification.forbidden == [] or self.specification.success == []
        if self.specification.forbidden != []:
            forbidden = [state for state in self.states if state in self.specification.forbidden]
            if forbidden != []:
                errormsg("forbidden states: " + str([state.name for state in forbidden]))
        if self.specification.success != []:
            if not exists(self.specification.success,self.states):
                errormsg("no success achieved")

class Learner:
    def __init__(self,specification):
        self.spec = specification
        self.monitor = Monitor(specification)
        self.generator = NameGenerator("S")

    def getSpec(self):
        return self.spec
    
    def begin(self):
        if self.spec.getInitial() == []:
            state = State(self.generator.next())
            self.spec.addState(state)
            self.spec.addInitial(state)
        self.monitor.begin()

    def end(self):
        for state in self.monitor.states:
            self.spec.addSuccess(state)
              
    def next(self,event):
        pre_states = self.monitor.getStates()
        debug("next learning: " + str(pre_states))
        self.monitor.next(event)
        post_states = self.monitor.getStates()
        if post_states == []:
            debug("no new states, we must learn")
            targetstate = State(self.generator.next())
            for sourcestate in pre_states:
                sourcestate.addRule(Rule([event],[targetstate]))
            self.monitor.addState(targetstate)
            self.spec.addState(targetstate)

    def learnlog(self,log):
        self.begin()
        for event in log:
            self.next(event)
        self.end()
        return self.spec
                
### example ###
    
c1 = Cmd(1)
c2 = Cmd(2)
c3 = Cmd(3)

e1 = Evr(1)
e2 = Evr(2)
e3 = Evr(3)   

def learn1():
    spec = Specification("LogPattern")
    state1   = State("S1")
    state2   = State("S2")
    state3   = State("S3")
    state4   = State("S4")
    state5   = State("S5")
    state6   = State("S6")
    state7   = State("S7")
    state8   = State("S8")
    state9   = State("S9")
    state10 = State("S10")

    spec.addState(state1)
    spec.addState(state2)
    spec.addState(state3)
    spec.addState(state4)
    spec.addState(state5)
    spec.addState(state6)
    spec.addState(state7)
    spec.addState(state8)
    spec.addState(state9)
    spec.addState(state10)

    state1.addRule(Rule([c1],[state2]))
    state2.addRule(Rule([e1],[state3]))
    state3.addRule(Rule([e2],[state4]))
    state4.addRule(Rule([c2],[state5]))
    state5.addRule(Rule([e3],[state6]))

    state2.addRule(Rule([e2],[state7]))
    state7.addRule(Rule([e1],[state8]))
    state8.addRule(Rule([c2],[state9]))
    state9.addRule(Rule([e3],[state10]))

    spec.addInitial(state1)
    spec.addSuccess(state6)
    spec.addSuccess(state10)

    return spec

log1 = [c1,e1,e2,c2,e3]
log2 = [c1,e2,e1,c2,e3]
log3 = [c1,e2,e1,c2]

learner = Learner(Specification("LogPattern"))

spec1 = learner.learnlog(log1)
spec1.write()

spec2 = learner.learnlog(log2)
spec2.write()

#mon = Monitor(spec1)

#mon.monitor(log1)
#mon.monitor(log2)
#mon.monitor(log3)
   