
### Events ###

class Cmd:
    def __init__(self,id,args=[]):
        self.id = id
        self.args = args
            
    def __repr__(self):
        return "cmd(" + str(self.id) + ")"

def strCmd(cmd):
    return "cmd(" + str(cmd.id) + ")"

def newCmd(id):
    return Cmd(id)

class Dpr:
    def __init__(self,id):
        self.id = id
    
    def __repr__(self):
        return "dpr(" + str(self.id) + ")"

    # productTable
    # Example
    # status
    # eventTime
    # type
    # transactionId
    # apid
    # totalParts
    # dvtCoarse
    # dvtFine
    # dvtScet
    # dvtSclk
    # partNumbers
    # completeFile
    # requestId
    # priority
    # partialFiles
    # reason
    # requestId
    # priority

def strDpr(dpr):
    return "dpr(" + str(dpr.id) + ")"

def newDpr(id):
    return Dpr(id)

class Evr:
    def __init__(self,name,level,eventId,message,fromSse,eventTime,realtime,sclk,scet,ert,module,metadata):
        self.name = name
        self.level = level
        self.eventId = eventId
        self.message = message
        self.fromSse = fromSse
        self.eventTime = eventTime
        self.realtime = realtime
        self.sclk = sclk
        self.scet = scet
        self.ert = ert
        self.module = module
        self.metadata = metadata

    def __repr__(self):
        return "evr(" + str(self.eventId) + ")"

    # evrList (Chris Delp)
    # Example:
    # name="CMD_EVR_CMD_COMPLETED_SUCCESS",
    # level="COMMAND",
    # eventId=7707,
    # message="Successfully completed command CMD_NO_OP_U8 (07e1): number=5.",
    # fromSse=False,
    # eventTime : (Chris Delp)
    # realtime=True,
    # sclk="0000003411.10352",
    # scet="2000-001T12:55:46.919",
    # ert="2008-263T23:24:50.207",
    # module="cmd",
    # metadata=[('TaskName', 'cmd???'), ('SequenceId', 'RT:6011'), ('CategorySequenceId', '9')]

def strEvr(evr):
    return "evr(" + str(evr.eventId) + ")"

def newEvr(eventId):
    return Evr("event","EVR",eventId,"hello there",False,True,True,"1","2","3","M",[])

class Eha:
    def __init__(self,receiveTime,eventTime,sclk,ert,scet,channelId,type,dn,dnUnits,eu,euUnits,status,alarms):
        self.receiveTime = receiveTime
        self.eventTime = eventTime
        self.sclk = sclk
        self.ert = ert
        self.scet = scet
        self.channelId = channelId
        self.type = type
        self.dn = dn
        self.dnUnits = dnUnits
        self.eu = eu
        self.euUnits = euUnits
        self.status = status
        self.alarms = alarms
         
    def __repr__(self):
        return "chan(" + str(self.channelId) + "," + str(self.dn) + ")"

    # channelValueTable
    # Example:
    # receiveTime="1221866865.0",
    # eventTime="2008-263T23:27:44.956",
    # sclk="0000004357.75001",
    # ert="2008-263T23:27:44.897",
    # scet="2000-001T13:11:33.566",
    # channelId="CMD-0001",
    # type="UNSIGNED_INT",
    # dn="8",
    # dnUnits="none",
    # eu=None,
    # euUnits="",
    # status="None",
    # alarms=[]

def strEha(eha):
    return "chan(" + str(eha.channelId) + "," + str(eha.dn) + ")"
        
def newEha(channelId,dn):
    return Eha("1","2","3","4","5",channelId,"int",dn,"none",None,"","None",[])

def strEvent(event):
    if isCmd(event):
        return strCmd(event)
    if isDpr(event):
        return strDpr(event)
    if isEvr(event):
        return strEvr(event)
    if isEha(event):
        return strEha(event)

### event-kind checkers ###

def classNameOf(event):
    return event.__class__.__name__

def isCmd(event):
    return classNameOf(event) == "Cmd"

def isEvr(event):
    return classNameOf(event) == "Evr"

def isDpr(event):
    return classNameOf(event) == "Dpr"

def isEha(event):
    return classNameOf(event) == "Eha" 

def sameCmd(cmd1,cmd2):
    return isCmd(cmd1) and isCmd(cmd2) and cmd1.id == cmd2.id

def sameEvr(event1,event2):
    return isEvr(event1) and isEvr(event2) and event1.eventId == event2.eventId

def sameDpr(event1,event2):
    return isDpr(event1) and isDpr(event2) and event1.id == event2.id

def sameEha(event1,event2):
    return isEha(event1) and isEha(event2) and event1.channelId == event2.channelId

def getChannelId(event):
    assert isEha(event)
    return event.channelId

def compare(event1,event2):
    if event1.scet < event2.scet:
        return -1
    if event1.scet == event2.scet:
        return 0
    if event1.scet > event2.scet:
        return 1  

# channelId
# dn
# createCondition
