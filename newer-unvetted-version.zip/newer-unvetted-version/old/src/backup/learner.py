
import copy

DEBUG = False

def debug(str):
    if DEBUG:
        print "--" + str

def min(x,y):
    if x <= y:
        return x
    else:
        return y
    
def max(x,y):
    if x >= y:
        return x
    else:
        return y

class Evr:
    def __init__(self,name,level,eventId,message,fromSse,realtime,sclk,scet,ert,module,metadata):
        self.name = name
        self.level = level
        self.eventId = eventId
        self.message = message
        self.fromSse = fromSse
        self.realtime = realtime
        self.sclk = sclk
        self.scet = scet
        self.ert = ert
        self.module = module
        self.metadata = metadata

    def __repr__(self):
        return "evr(" + self.name + "," + self.level + "," + str(self.eventId) + ")"

        # Example:
        # name="CMD_EVR_CMD_COMPLETED_SUCCESS",
        # level="COMMAND",
        # eventId=7707,
        # message="Successfully completed command CMD_NO_OP_U8 (07e1): number=5.",
        # fromSse=False,
        # realtime=True,
        # sclk="0000003411.10352",
        # scet="2000-001T12:55:46.919",
        # ert="2008-263T23:24:50.207",
        # module="cmd",
        # metadata=[('TaskName', 'cmd???'), ('SequenceId', 'RT:6011'), ('CategorySequenceId', '9')]

class ChanVal:
    def __init__(self,receiveTime,eventTime,sclk,ert,scet,channelId,type,dn,dnUnits,eu,euUnits,status,alarms):
        self.receiveTime = receiveTime
        self.eventTime = eventTime
        self.sclk = sclk
        self.ert = ert
        self.scet = scet
        self.channelId = channelId
        self.type = type
        self.dn = dn
        self.dnUnits = dnUnits
        self.eu = eu
        self.euUnits = euUnits
        self.status = status
        self.alarms = alarms
    
    def __repr__(self):
        return "chan(" + str(self.channelId) + "," + str(self.dn) + ")"

        # Example:
        # receiveTime="1221866865.0",
        # eventTime="2008-263T23:27:44.956",
        # sclk="0000004357.75001",
        # ert="2008-263T23:27:44.897",
        # scet="2000-001T13:11:33.566",
        # channelId="CMD-0001",
        # type="UNSIGNED_INT",
        # dn="8",
        # dnUnits="none",
        # eu=None,
        # euUnits="",
        # status="None",
        # alarms=[]

def isCommand(event):
    return isinstance(event,Evr) and event.level == "COMMAND"

def isChannel(event):
    return isinstance(event,ChanVal)

def isEvr(event):
    return isinstance(event,Evr)

def sameEvent(event1,event2):
    return sameChannel(event1,event2) or sameEvr(event1,event2)

def sameChannel(event1,event2):
    return isChannel(event1) and isChannel(event2) and event1.channelId == event2.channelId

def sameEvr(event1,event2):
    return isEvr(event1) and isEvr(event2) and event1.eventId == event2.eventId

def intervalize(event):
    if isChannel(event):
        specevent = copy.copy(event)
        specevent.dn = (specevent.dn,specevent.dn)
        return specevent
    else:
        return event
    
class Observation:
    def __init__(self,event):
        self.event = intervalize(event)
        self.updated = True

    def sameEvent(self,event):
        return sameEvent(self.event,event)

    def refineEvent(self,event):
        if isChannel(event):
            (low,high) = self.event.dn
            newlow = min(low,event.dn)
            newhigh = max(high,event.dn)
            self.event.dn = (newlow,newhigh)

    def matches(self,event):
        if not self.sameEvent(event):
            return False
        else:
            if isChannel(event):
                (low,high) = self.event.dn
                return low <= event.dn <= high 
            else: # an Evr
                return True
                                
    def __repr__(self):
        if self.updated:
            updated = "!"
        else:
            updated = ""
        return str(self.event) + updated

class Monitor:
    def __init__(self,spec):
        self.spec = spec
        self.command = None
        self.obligations = None

    def monitor(self,log):
        print ""
        print "=== monitor: ==="
        print ""
        self.command = None
        self.obligations = None    
        for event in log:
            self.monitorEvent(event)
        self.checkObligations()
    
    def monitorEvent(self,event):
        debug("monitor event: " + str(event))
        if isCommand(event):
            self.checkObligations() # from previous command
            self.command = event
            self.obligations = self.spec.getObligations(event)
            debug("new obligations: " + str(self.obligations))
        else:
            if self.obligations != None and self.obligations != []:
                self.obligations = [obs for obs in self.obligations if not obs.matches(event)] 
                debug("resulting obligations: " + str(self.obligations))
                        
    def checkObligations(self):
        if self.obligations != None and self.obligations != []:
            print "command " + str(self.command) + " not followed by:"
            for observation in self.obligations:
                print "  " + str(observation)
        self.command = None
        self.obligations = None
                                        
class Specification:
    def __init__(self):
        self.map = {}
        self.current = None
        self.new = None

    def getObligations(self,event):
        assert isCommand(event)
        key = event.eventId
        if key in self.map:
            return self.map[key]
        else:
            return []

    def learn(self,log):
        debug("")
        debug("learning from log " + str(log))
        debug("")
        for event in log:
            debug("processing event: " + str(event))
            if isCommand(event):
                self.newCommand(event)
            else:
                self.addEvent(event)
        debug("termination of log")
        self.removeEvents() # for the last processed command
        self.current = None
                   
    def newCommand(self,event):
        assert isCommand(event)
        debug("this is a new command" )
        debug("")
        self.removeEvents() # for the previous command
        self.current = event.eventId
        if self.current in self.map:
            self.new = False
        else:
            self.new = True
            self.map[self.current] = []
            
    def addEvent(self,event):
        if self.new:
            self.add(event)
        else:
            self.refine(event)
           
    def add(self,event):
        for observation in self.map[self.current]:
            if observation.sameEvent(event):
                observation.refineEvent(event)
                return
        self.map[self.current].append(Observation(event))                                 
                                    
    def refine(self,event):
        for observation in self.map[self.current]:
            if observation.sameEvent(event):
                observation.refineEvent(event)
                observation.updated = True

    def removeEvents(self):
        if self.current != None:
            list = []
            for observation in self.map[self.current]:
                if observation.updated:
                    debug("keeping observation: " + str(observation))
                    observation.updated = False
                    list.append(observation)
                else:
                    debug("ignoring observation: " + str(observation))
            self.map[self.current] = list
            debug("resulting events: " + str(list))
            debug("")
               
    def __repr__(self):
        text = "\n=== learned specification: ===\n\n"
        for key in self.map.keys():
            observations = self.map[key]
            if observations != []:
                text += "command " + str(key) + " =>\n" 
                for observation in observations:
                    text += "  " + str(observation) + "\n"
        return text


###################
###  Experiment  ###
###################

def newEvr(name,level,eventId):
    return Evr(name,level,eventId,"hello there",False,True,"1","2","3","M",[])

def newChan(channelId,dn):
    return ChanVal("1","2","3","4","5",channelId,"int",dn,"none",None,"","None",[])

### event definitions ###

cmd1 = newEvr("C1","COMMAND",1)   
cmd2 = newEvr("C2","COMMAND",2)       
evr1 = newEvr("E1","EVENT",10)
evr2 = newEvr("E2","EVENT",20)
evr3 = newEvr("E3","EVENT",30)
evr4 = newEvr("E4","EVENT",40)
cha11 = newChan(100,1)
cha12 = newChan(100,2)
cha13 = newChan(100,3)
cha21 = newChan(200,1)
cha22 = newChan(200,2) 

### logs ###
        
log1 = [cmd1,evr1,evr2,evr3,cha11,cha21,cmd1,evr3,evr4,cha12]
log2 = [cmd2,evr3,cmd1,evr2,cha11,cha22,evr4]
log3 = [cmd1,cha13] 

### specification learning ###
 
s = Specification()
s.learn(log1)
s.learn(log2)
print str(s)

### monitoring ###

m = Monitor(s)
m.monitor(log3)

