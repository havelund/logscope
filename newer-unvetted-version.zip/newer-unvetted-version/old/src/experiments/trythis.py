
# general indexing functions

print "=== lists: ==="

l = [10,20,30]
print len(l)
print l[1]

print "=== strings: ==="

s = "Klaus"
print len(s)
print s[1]

print "=== maps: ==="

m = {1:"A",2:"B"}
print isinstance(m,dict)

print "=== bits: ==="

def getBitValue(n, p):
    '''                                                                                                                           
    get the bitvalue of denary (base 10) number n at the equivalent binary                                                        
    position p (binary count starts at position 0 from the right)                                                                 
    '''
    return (int(n) >> int(p)) & 1

i = 5
print getBitValue(i,2)
print int(4)

print "=== generalization: ==="

def indexMatches(source,index,value):
    if isinstance(source,int):
        if index <= 15: 
            return getBitValue(source,index) == value
    elif isinstance(source,list) or isinstance(source,str):
        if index < len(source):
            return source[index] == value
    elif isinstance(source,dict):
        if index in source:
            return source[index] == value
    return False

print indexMatches(l,1,20)
print indexMatches(l,2,20)
print indexMatches(l,10,20)

print "--- list ---"

print indexMatches(l,1,20)
print indexMatches(l,2,20)
print indexMatches(l,10,20)

print "--- string ---"

print indexMatches(s,1,"l")
print indexMatches(s,2,"x")
print indexMatches(s,10,"b")

print "--- map ---"

print indexMatches(m,1,"A")
print indexMatches(m,2,"X")
print indexMatches(m,10,"b")

print "--- bits ---"

print indexMatches(i,0,1)
print indexMatches(i,1,1)
print indexMatches(i,10,0)
print indexMatches(i,200,1)

print int(200)

print "================"

print "\"Klaus".startswith(".")
