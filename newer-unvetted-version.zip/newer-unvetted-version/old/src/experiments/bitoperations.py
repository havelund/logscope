
# a look at bitwise (binary) operations
# a bit is either 0 or 1
# a nibble has 4 bits
# a byte has 8 bits
# tested with Python24   vegaseat    19aug2005
 
def Denary2Binary(n):
    '''convert denary (base 10) integer n to binary string bStr'''
    bStr = ''
    if n < 0:  raise ValueError, "must be a positive"
    if n == 0: return '0'
    while n > 0:
        bStr = str(n % 2) + bStr
        n = n >> 1
    return bStr
 
def getBitValue(n, p):
    '''
    get the bitvalue of denary (base 10) number n at the equivalent binary
    position p (binary count starts at position 0 from the right)
    '''
    return (n >> p) & 1
 
print "-"*50
x = -8
print "the bits of x inverted using ~" 
print "~%x = denary %d = binary %s" % (x, ~x, Denary2Binary(~x))
 
print "-"*50
 
# bitwise and is &
x = 8
y = 15
print "bitwise and is & (only 1 & 1 = 1)"
print "x = denary %d = binary %s" % (x, Denary2Binary(x))
print "y = denary %d = binary %s" % (y, Denary2Binary(y))
print "x & y = denary %d = binary %s" % (x & y, Denary2Binary(x & y))
 
print "-"*50
 
# bitwise or is |
x = 8
y = 15
print "bitwise or is | (1 | 1 = 1 also 1 | 0 = 1)"
print "x = denary %d = binary %s" % (x, Denary2Binary(x))
print "y = denary %d = binary %s" % (y, Denary2Binary(y))
print "x | y = denary %d = binary %s" % (x | y, Denary2Binary(x | y))
 
print "-"*50
 
# bitwise exclusive or is ^
x = 8
y = 15
print "bitwise exclusive or is ^ (only 1 ^ 0 = 1))"
print "x = denary %d = binary %s" % (x, Denary2Binary(x))
print "y = denary %d = binary %s" % (y, Denary2Binary(y))
print "x ^ y = denary %d = binary %s" % (x ^ y, Denary2Binary(x ^ y))
 
 
print "-"*50
 
# ShiftRight  x >> n   x shifted right by n bits
# is equivalent to division by pow(2, n) without overflow check
x = 16
print "x >> n   x shifted right by n bits"
print "%d = binary %s" % (x, Denary2Binary(x))
print "%d >> 1 = denary %d = binary %s" % (x, x >> 1, Denary2Binary(x >> 1))
print "%d >> 2 = denary %d = binary %s" % (x, x >> 2, Denary2Binary(x >> 2))
print "%d >> 3 = denary %d = binary %s" % (x, x >> 3, Denary2Binary(x >> 3))
print "%d >> 4 = denary %d = binary %s" % (x, x >> 4, Denary2Binary(x >> 4))
print "%d >> 5 = denary %d = binary %s" % (x, x >> 5, Denary2Binary(x >> 5))
 
print "-"*50
 
# ShiftLeft  x << n   x shifted left by n bits
# is equivalent to multiplication by pow(2, n) without overflow check
x = 1
print "x << n   x shifted left by n bits"
print "%d = binary %s" % (x, Denary2Binary(x))
print "%d << 1 = denary %d = binary %s" % (x, x << 1, Denary2Binary(x << 1))
print "%d << 2 = denary %d = binary %s" % (x, x << 2, Denary2Binary(x << 2))
print "%d << 3 = denary %d = binary %s" % (x, x << 3, Denary2Binary(x << 3))
print "%d << 4 = denary %d = binary %s" % (x, x << 4, Denary2Binary(x << 4))
print "%d << 5 = denary %d = binary %s" % (x, x << 5, Denary2Binary(x << 5))
 
print "-"*50
 
print "What is the bit value of 16 (binary 10000) at position 4?"
print "(binary positions start at the right with position zero)"
print getBitValue(16, 4)

print "==============================="

n = 10

print str(n) + " = " + Denary2Binary(n)

print ""

print  getBitValue(n, 0)
print  getBitValue(n, 1)
print  getBitValue(n, 2)
print  getBitValue(n, 3)
print  getBitValue(n, 4)
print  getBitValue(n, 5)





