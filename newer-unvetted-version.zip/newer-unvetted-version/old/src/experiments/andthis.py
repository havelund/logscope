
import string

n1 = "error1"
n2 = "error"

def startswith(str1,str2):
    return string.count(str1,str2,0,len(str2))

print startswith("errorabc","error")
