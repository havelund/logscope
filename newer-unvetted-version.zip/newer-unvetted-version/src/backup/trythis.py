
import re

state1 = "Klaus"
state2 = "L0_1"

pattern = "L(\d+)\\_"

match1 = re.match(pattern,state1)

print match1

match2 = re.match(pattern,state2)

print match2

print match2.group(1)