
import sys

thismodule = sys.modules["lsm.predicates"]

def less(x,y):
    return x < y

def equal(x,y):
    return x == y 

def less_equal(x,y):
    return x <= y

def greater(x,y):
    return x > y

def greater_equal(x,y):
    return x >= y

def contains(s,t):
    return s.find(t) != -1

def applypredicate(predicateName,arguments):
    predicate = getattr(thismodule,predicateName)
    return apply(predicate,arguments)
