
import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm
 
class TestPythonStrings(unittest.TestCase):
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec12")
 
    def test1(self):                   
        '''should yield no errors'''
        log = [
                 COMMAND({'Stem' : "CAMERA_SHOOT"}),
                 EVR({'Stem' : "CAMERA_SHOOT", 'Message' : "there is a picture taken and it is good"}),
                  ]
        checkErrors_(self.observer.monitor(log),[])

    def test2(self):                   
        '''should yield no errors'''
        log = [
                 COMMAND({'Stem' : "CAM_SHOOT"}), # does not match prefix "CAMERA_", so monitor does not trigger
                 EVR({'Stem' : "CAM_SHOOT", 'Message' : "there is a picture taken and it is over-exposed"}), # although this contains "over-exposed"
                  ]
        checkErrors_(self.observer.monitor(log),[])

    def test3(self):                   
        '''should yield error'''
        log = [
                 COMMAND({'Stem' : "CAMERA_SHOOT"}), # now matches
                 EVR({'Stem' : "CAMERA_SHOOT", 'Message' : "there is a picture taken and it is over-exposed"}), # and is over-exposed
                  ]
        checkErrors_(self.observer.monitor(log),[
            {"K"  : "liveness", 
             "P" : "P", 
             "M" : "hot end state", 
             "S" : "S2", 
             "B"  : {'x': 'CAMERA_SHOOT'},
             "H"  : [COMMAND({'Stem' : "CAMERA_SHOOT"})],
            }                                                             
        ])
            
                    
if __name__ == '__main__':
    unittest.main()
    