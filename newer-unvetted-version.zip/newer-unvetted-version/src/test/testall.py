
import unittest

#from testcore import *
#from testspeclang import *
#from testobserver import *
#from testparameters import *
#from testcommands import *
#from testlogfile import *
#from testlogfile2 import *

import testlearner
import testparser
import testerrormessages
import testindexranges
import testbitstrings
import testpredicates
import testconsequencebindings
import testonceoption
import testpythoncode
import testpythonstrings  
import testexpressionpredicates
import testscope
import testuptoscope
import testruntypechecking    
import testdeadspecs
import testoperations
  
load = unittest.TestLoader().loadTestsFromTestCase
 
suite1 = unittest.TestSuite(
                            [
                             load(testlearner.TestLearner),
                             load(testparser.TestParser),
                             load(testerrormessages.TestErrorMessages),
                             load(testindexranges.TestIndexRanges),
                             load(testbitstrings.TestBitStrings),
                             load(testpredicates.TestPredicates),
                             load(testconsequencebindings.TestConsequenceBindings),
                             load(testonceoption.TestOnceOption),
                             load(testpythoncode.TestPythonCode),
                             load(testpythonstrings.TestPythonStrings),
                             load(testexpressionpredicates.TestExpressionPredicates),
                             load(testscope.TestScope),
                             load(testuptoscope.TestUptoScope),
                             load(testruntypechecking.TestRuntypeChecking),
                             load(testdeadspecs.TestDeadSpecs), 
                             load(testoperations.TestOperations)  
                             ]
                            )

unittest.TextTestRunner(verbosity=2).run(suite1)

# load(TestCore),
# load(TestSpecLanguage),
# load(TestObserver),
# load(TestParameters),
# load(TestCommands),
# load(TestLogFile),
# load(TestLogFile2),