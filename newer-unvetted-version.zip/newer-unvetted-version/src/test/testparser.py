
import unittest
from lsm.unittest import *

import lsm.lsm as lsm
   
class TestParser(unittest.TestCase):

    def test1(self):        

        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
   
        observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec3")
        events = lsm.unpickle_logfile("/Users/khavelun/Desktop/MSLPICKLE/pickled_events.pic")
        
        results = observer.monitor(events)
        
        checkErrorCounts_(results,{
            "HardwareDispatch" :  3, # important test
            "SoftwareHardware" : 194, # important test
            "SoftwareSuccess" : 191, # important test
            "SoftwareSuccessGoneWild" : 314, # not important (verified)
            "SoftwareSuccessRelaxed" : 385,  # not important (verified)
            "do_succeed" : 23, # not important (verified)
            "only_one_success" :  2 # not important (verified)                 
        })
                
        #print "RESULTS:\n" , str(results)
                
        #statobs = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/CommandSuccess")
        #results = statobs.monitor(events)      
        #lsm.Spreadsheet(results[0],"/Users/khavelun/Desktop/MSLPICKLE/spreadsheet.txt")                
                
                
if __name__ == '__main__':
    unittest.main()
