
### RV TUTORIAL PAPER EXAMPLE ###

import lsm.lsm as lsm

# create an event log, in this case hand-made, but can also be extracted with log file extractor:

log = [
          {"OBJ_TYPE" : "COMMAND", "Type" : "FSW", 
             "Stem" : "PIC_4", "Number" : 231, "Bit" : 1, "Size" : 2000},
          {"OBJ_TYPE" : "EVR", "Dispatch" : "PIC_4", "Number" : 231},
          {"OBJ_TYPE" : "CHANNEL", "DataNumber" : 5},
          {"OBJ_TYPE" : "EVR", "Success" : "PIC_4", "Number" : 231},
          {"OBJ_TYPE" : "PRODUCT", "ImageSize" : 1200}
       ]

# specify absolute path of where results should be stored (.dot files and RESULT file):
           
lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")   

# instantiate the Observer class providing a total path name of specification file:

observer = lsm.Observer("specs/rv-tutorial-paper")

# call the observer's monitor function on the log:

observer.monitor(log)
        