
def mindre_lig(x,y):
    return x <= y

