
import unittest
from lsm.unittest import *

import lsm.lsm as lsm

class TestErrorMessages(unittest.TestCase):

    def test1(self):         

        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
   
        observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec5")
        
        log = [
                  COMMAND({"Type" : "FlightSoftwareCommand", "Stem" : "TURN", "Number" : 1}),
                  EVR({"Dispatch" : "TURN", "Number" : 1}),
                  EVR({"Failure" : "TURN", "Number" : 1}),
                  EVR({"DispatchFailure" : "TURN", "Number" : 1})
                  ]
        checkErrors_(observer.monitor(log), [
            {"K" : "safety", 
             "P" : "CommandFlow", 
             "M" :"violated: by event 3", 
             "S" : "S3", 
             "B" : {'y': 1, 'x': 'TURN'},
             "H" : [COMMAND({'Stem' : 'TURN', 'Number' : 1}),EVR({'Dispatch' : 'TURN', 'Number' : 1})],
             "N" : 3, 
             "E" : EVR({'Failure' : 'TURN', 'Number' : 1}), 
             "T" : 1 
            },   
           {"K" : "liveness", 
             "P" : "CommandSuccess", 
             "M" :"with bindings: {'y': 1, 'x': 'TURN'}", 
             "S" : "S3", 
             "B" : {'y': 1, 'x': 'TURN'},
             "H" : [COMMAND({'Stem' : 'TURN', 'Number' : 1}),EVR({'Dispatch' : 'TURN', 'Number' : 1})]
            },   
            {"K"  : "liveness", 
             "P" : "CommandSuccessRule1",
             "M" : ["violated: none of the success states have been reached",
                      "step wait_success(x,y) ",
                      "with bindings: {'y': 1, 'x': 'TURN'}",
                      "--- error trace: ---",
                      "Stem := \"TURN\"",
                      "Dispatch := \"TURN\""]
            },
            {"K"  : "liveness", 
             "P" : "CommandSuccessRule2",
             "M" : ["violated: none of the success states have been reached",
                      "step wait_success(x,y) ",
                      "with bindings: {'y': 1, 'x': 'TURN'}",
                      "--- error trace: ---",
                      "Stem := \"TURN\"",
                      "Dispatch := \"TURN\""]
            }
        ]) 
                       
if __name__ == '__main__':
    unittest.main()
  