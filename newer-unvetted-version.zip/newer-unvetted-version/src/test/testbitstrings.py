
import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm
 
class TestBitStrings(unittest.TestCase):
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec7")
 
    def test1(self):                   
        '''should yield no errors'''
        log = [
                  COMMAND({"Stem" :"TURN", "Bitvector" : 512,"Args" : [0,1,{"bitvector" : 512}]}), 
                  EVR({"Success" : "TURN", "Status" : 512, "ResultDict" : {"Status" : 512}})
                  ]
        checkErrors_(self.observer.monitor(log),[])

    def test2(self):                   
        '''should yield no errors.
        Changed all 512 numbers to strings'''
        log = [
                  COMMAND({"Stem" :"TURN", "Bitvector" : "512","Args" : [0,1,{"bitvector" : "512"}]}), 
                  EVR({"Success" : "TURN", "Status" : "512", "ResultDict" : {"Status" : "512"}})
                  ]
        checkErrors_(self.observer.monitor(log),[])

    def test3(self):                   
        '''should yield no errors.
        Changed all 512 numbers to strings'''
        log = [
                  COMMAND({"Stem" :"TURN", "Bitvector" : 512,"Args" : [0,1,{"bitvector" : 512}]}), 
                  EVR({"Success" : "TURN", "Status" : "5", "ResultDict" : {"Status" : "512"}})
                  ]
        results = self.observer.monitor(log)
        checkErrorCount_(results,2)

    def test4(self):                   
        '''should yield no errors.
        Changed all 512 numbers to strings'''
        log = [
                  COMMAND({"Stem" :"TURN", "Bitvector" : 512,"Args" : [0,1,{"bitvector" : 512}]}), 
                  EVR({"Success" : "TURN", "Status" : "512", "ResultDict" : {"Status" : "5"}})
                  ]
        results = self.observer.monitor(log)
        checkErrorCount_(results,2)


if __name__ == '__main__':
    unittest.main()