import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm
 
class TestOnceOption(unittest.TestCase):
    '''Testing an error scenario exposed in one of Lisa's log files.
    The option Options.once was turned on (True) and this caused the specification
    in spec10 to be violated in test4 below. This option should be set to False.
    '''

    # spec10 (repeated here):
    # pattern PWR_UTIL_TEST_45 :
    #   COMMAND{Stem: "PWR_UTIL_TEST", Number: "45"} =>
    #   {
    #     CHANNEL{channelId: "PWR-0004", DN: {13: 1}},
    #     CHANNEL{channelId: "PWR-0004", DN: {9: 1}},
    #     CHANNEL{channelId: "PWR-0007", DN: {3: 1}}
    #   }
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec10")
 
    def test1(self):                   
        '''should yield no errors, minimal log file to demonstrate this'''
        log = [
                    COMMAND({'Stem' : "PWR_UTIL_TEST", 'Number' : "45"}),
                    CHANNEL({'channelId' : "PWR-0004", 'DN' : "8704"}), # DN bit 13=1 and DN bit 9=1
                    CHANNEL({'channelId' : "PWR-0007", 'DN' : "136"}) # bit 3=1
                  ]
        self.assertEqual(Options.once,False)
        checkErrors_(self.observer.monitor(log),[])     

    def test2(self):                   
        '''should yield no errors, added extra noise events'''
        log = [
                    COMMAND({'Stem' : "PWR_UTIL_TEST", 'Number' : "45"}),
                    EVR({'Message' : "some random message"}), # does not matter
                    CHANNEL({'channelId' : "PWR-0004", 'DN' : None}), # should not match (DN is None)
                    CHANNEL({'channelId' : "PWR-0007", 'DN' : "128"}),  # should not match (DN bit 3=0)
                    CHANNEL({'channelId' : "PWR-0004", 'DN' : "8704"}), # DN bit 13=1 and DN bit 9=1
                    CHANNEL({'channelId' : "PWR-0007", 'DN' : "136"}) # bit 3=1
                  ]
        self.assertEqual(Options.once,False)
        checkErrors_(self.observer.monitor(log),[])  

    def test3(self):                   
        '''should yield 3 liveness errors since all expected CHANNEL events are missing'''
        log = [
                    COMMAND({'Stem' : "PWR_UTIL_TEST", 'Number' : "45"}),
                    EVR({'Message' : "some random message"}), # does not matter
                    CHANNEL({'channelId' : "PWR-0004", 'DN' : None}), # should not match (DN is None)
                    CHANNEL({'channelId' : "PWR-0007", 'DN' : "128"}),  # should not match (DN bit 3=0)
                  ]
        self.assertEqual(Options.once,False)
        checkErrors_(self.observer.monitor(log), [
            {"K"  : "liveness", 
             "P" : "PWR_UTIL_TEST_45", 
             "M" : "hot end state", 
             "S" : "S2", 
             "B"  : {},
             "H"  : [COMMAND({'Stem' : "PWR_UTIL_TEST", 'Number' : "45"})],
            },
            {"K"  : "liveness", 
             "P" : "PWR_UTIL_TEST_45", 
             "M" : "hot end state", 
             "S" : "S4", 
             "B"  : {},
             "H"  : [COMMAND({'Stem' : "PWR_UTIL_TEST", 'Number' : "45"})],
            },
            {"K"  : "liveness", 
             "P" : "PWR_UTIL_TEST_45", 
             "M" : "hot end state", 
             "S" : "S6", 
             "B"  : {},
             "H"  : [COMMAND({'Stem' : "PWR_UTIL_TEST", 'Number' : "45"})],
            }                                                                                  
        ])                                                  
                   
    def test4(self):                   
        '''should yield 1 error since Options.once=True option prevents the 9 bit to be tested'''
        log = [
                    COMMAND({'Stem' : "PWR_UTIL_TEST", 'Number' : "45"}),
                    CHANNEL({'channelId' : "PWR-0004", 'DN' : "8704"}), # DN bit 13=1 and DN bit 9=1
                    CHANNEL({'channelId' : "PWR-0007", 'DN' : "136"}) # bit 3=1
                  ]
        print "setting Options.once to True"
        Options.once = True
        self.assertEqual(Options.once,True)
        checkErrors_(self.observer.monitor(log), [
            {"K"  : "liveness", 
             "P" : "PWR_UTIL_TEST_45", 
             "M" : "hot end state", 
             "S" : "S4", 
             "B"  : {},
             "H"  : [COMMAND({'Stem' : "PWR_UTIL_TEST", 'Number' : "45"})],
            }                                                      
        ])
        Options.once = False         

                    
if __name__ == '__main__':
    unittest.main()
