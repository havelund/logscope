
import lsm.lsm as logscope
import re

LOGFILE = "/Users/khavelun/Desktop/test/python/promela.log"    
SPECFILE = "/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/statechart-spec"
RESULTS = "/Users/khavelun/Desktop/MSLRESULT"

logscope.setResultDir(RESULTS)

def readLog(file):
  log = []
  regexp = re.compile("\*\*\* (s\d*) (Exit|Init)")
  for line in file:                                                                                                                  
    match  = regexp.search(line) 
    state = match.group(1)                                                                                                       
    type = match.group(2)
    event = {"OBJ_TYPE" : "EVR", "Type" : type, "State" : state}
    log.append(event)
    print event
  return log

file = open(LOGFILE)
log = readLog(file)
                
logscope.Observer(SPECFILE).monitor(log)
