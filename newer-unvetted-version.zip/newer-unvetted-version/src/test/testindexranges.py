
import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm
 
class TestIndexRanges(unittest.TestCase):
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec6")
 
    def test1(self):                   
        '''should yield no errors'''
        log = [
                  COMMAND({"Stem" :"TURN", "Args" : [2009,"test 1",{"x" : 100, "y" : 200, "bitvector" : 5}]}), # year, testnr, xdegree, onoff
                  EVR({"Dispatch" : "TURN", "TestNumber" : "1"}),
                  EVR({"Success" : "TURN", "List" : ["Mars","Science","Laboratory",{"x" : 100, "y" : 200},2009]}),
                  EVR({"Conclusion" : "TURN", "Dict" : {"LarsLetters" : ["L","a","R","S",1], 2 : 2009}})
                  ]
        checkErrors_(self.observer.monitor(log),[])
        
    def test2(self):
        '''testnr changed to an int in event 2'''        
        log = [
                  COMMAND({"Stem" :"TURN", "Args" : [2009,"test 1",{"x" : 100, "y" : 200, "bitvector" : 5}]}), # year, testnr, xdegree, onoff
                  EVR({"Dispatch" : "TURN", "TestNumber" : 2}), # changed testnr to an int
                  EVR({"Success" : "TURN", "List" : ["Mars","Science","Laboratory",{"x" : 100, "y" : 200},2009]}),
                  EVR({"Conclusion" : "TURN", "Dict" : {"LarsLetters" : ["L","a","R","S",1], 2 : 2009}})
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K"  : "liveness", 
             "P" : "P1", 
             "M" : "hot end state", 
             "S" : "S2", 
             "B"  : {'testnr': '1', 'cmd': 'TURN', 'onoff': 1, 'xdegree': 100, 'year': 2009},
             "H"  : [COMMAND({'Stem' : 'TURN'})],
            },
            {"K" : "safety", 
             "P" : "P2", 
             "M" :"state S2(cmd,year,testnr,xdegree,onoff)", 
             "S" : "S2", 
             "B" : {'testnr': '1', 'cmd': 'TURN', 'onoff': 1, 'xdegree': 100, 'year': 2009},
             "H" : [COMMAND({'Stem' : 'TURN', 'Args' :  [2009, 'test 1', {'y': 200, 'x': 100, 'bitvector': 5}]})],
             "N" : 2, 
             "E" : EVR({'Dispatch' : 'TURN','TestNumber' : 2}), 
             "T" : 1
           }                                                                                                                                                     
        ])        
        
    def test3(self):
        '''xdegree changed to 101 in event 3'''
        log = [
                  COMMAND({"Stem" :"TURN", "Args" : [2009,"test 1",{"x" : 100, "y" : 200, "bitvector" : 5}]}), # year, testnr, xdegree, onoff
                  EVR({"Dispatch" : "TURN", "TestNumber" : "1"}),
                  EVR({"Success" : "TURN", "List" : ["Mars","Science","Laboratory",{"x" : 101, "y" : 200},2009]}), # changed xdegree
                  EVR({"Conclusion" : "TURN", "Dict" : {"LarsLetters" : ["L","a","R","S",1], 2 : 2009}})
                  ]
        checkErrors_(self.observer.monitor(log),[
            {"K"  : "liveness", 
             "P" : "P1", 
             "M" : "hot end state", 
             "S" : "S3", 
             "B"  : {'testnr': '1', 'cmd': 'TURN', 'onoff': 1, 'xdegree': 100, 'year': 2009},
             "H"  : [COMMAND({'Stem' : 'TURN'}),EVR({'Dispatch' : 'TURN', 'TestNumber' : '1'})],
            },
            {"K" : "safety", 
             "P" : "P2", 
             "M" :"state S3(cmd,year,testnr,xdegree,onoff)", 
             "S" : "S3", 
             "B" : {'testnr': '1', 'cmd': 'TURN', 'onoff': 1, 'xdegree': 100, 'year': 2009},
             "H" : [COMMAND({'Stem' : 'TURN'}),EVR({'TestNumber' : '1', 'Dispatch' : 'TURN'})],
             "N" : 3, 
             "E" : EVR({'Success' : 'TURN', 'List' : ['Mars', 'Science', 'Laboratory', {'y': 200, 'x': 101}, 2009]}), 
             "T" : 1
            }                    
        ])
                             
    def test4(self):
        '''year changed to 2010 in event 3'''
        log = [
                  COMMAND({"Stem" :"TURN", "Args" : [2009,"test 1",{"x" : 100, "y" : 200, "bitvector" : 5}]}), # year, testnr, xdegree, onoff
                  EVR({"Dispatch" : "TURN", "TestNumber" : "1"}),
                  EVR({"Success" : "TURN", "List" : ["Mars","Science","Laboratory",{"x" : 100, "y" : 200},2010]}), # changed year
                  EVR({"Conclusion" : "TURN", "Dict" : {"LarsLetters" : ["L","a","R","S",1], 2 : 2009}})
                  ]
        checkErrors_(self.observer.monitor(log),[
            {"K"  : "liveness", 
             "P" : "P1", 
             "M" : "hot end state", 
             "S" : "S3", 
             "B"  :  {'testnr': '1', 'cmd': 'TURN', 'onoff': 1, 'xdegree': 100, 'year': 2009},
             "H"  : [COMMAND({'Stem' : 'TURN'}),EVR({'Dispatch' : 'TURN', 'TestNumber' : '1'})],
            },
            {"K" : "safety", 
             "P" : "P2", 
             "M" :"by transition 2 : EVR{'List': {0: \"Mars\", 3: {'y': 200, 'x': 100}, 4: 2010}, 'Success': 'TURN'} => error", 
             "S" : "S3", 
             "B" : {'testnr': '1', 'cmd': 'TURN', 'onoff': 1, 'xdegree': 100, 'year': 2009},
             "H" : [COMMAND({'Stem' : 'TURN'}),EVR({'TestNumber' : '1', 'Dispatch' : 'TURN'})],
             "N" : 3, 
             "E" : EVR({'Success' : 'TURN', 'List' : ['Mars', 'Science', 'Laboratory', {'y': 200, 'x': 100}, 2010]}), 
             "T" : 2
            }                    
        ])

    def test5(self):
        '''onoff changed to 0 in event 4'''
        log = [
                  COMMAND({"Stem" :"TURN", "Args" : [2009,"test 1",{"x" : 100, "y" : 200, "bitvector" : 5}]}), # year, testnr, xdegree, onoff
                  EVR({"Dispatch" : "TURN", "TestNumber" : "1"}),
                  EVR({"Success" : "TURN", "List" : ["Mars","Science","Laboratory",{"x" : 100, "y" : 200},2009]}),
                  EVR({"Conclusion" : "TURN", "Dict" : {"LarsLetters" : ["L","a","R","S",0], 2 : 2009}}) # changed onoff
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K"  : "liveness", 
             "P" : "P1", 
             "M" : "hot end state", 
             "S" : "S4", 
             "B"  : {"cmd" : "TURN"},
             "H"  : [COMMAND({'Stem' : 'TURN'}),EVR({'Dispatch' : 'TURN'}),EVR({})],
            },
            {"K" : "safety", 
             "P" : "P2", 
             "M" :"by event 4", 
             "S" : "S4", 
             "B" : {"cmd" : "TURN"},
             "H" : [COMMAND({'Stem' : 'TURN'}),EVR({'Dispatch' : 'TURN'}),EVR({'Success' : 'TURN'})],
             "N" : 4, 
             "E" : EVR({'Conclusion' : 'TURN'}), 
             "T" : 1
            }                                                                                                                                                     
        ]) 
                       
if __name__ == '__main__':
    unittest.main()
