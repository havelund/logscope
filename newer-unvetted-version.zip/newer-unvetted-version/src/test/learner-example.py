
### MANUAL EXAMPLE ###

import lsm.lsm as lsm
          
# create event logs, in this case hand-made for illustration; will typically be extracted with log file extractor:

log1 = [
          {"OBJ_TYPE" : "COMMAND", "Stem" : "PICT"},
          {"OBJ_TYPE" : "EVR", "Dispatch" : "PICT", "EventId" : 2, "Module" : "dispatcher", "Message" : "dispatch done!"},
          {"OBJ_TYPE" : "CHANNEL", "ChannelId" : 3, "DataNumber" : 5},
          {"OBJ_TYPE" : "EVR", "Success" : "PICT", "EventId" : 3,"Message" : "command succeeded!"},
          {"OBJ_TYPE" : "PRODUCT", "Name" : "Image", "ImageSize" : 1200}
       ]

log2 = [
          {"OBJ_TYPE" : "COMMAND", "Stem" : "PICT"},
          {"OBJ_TYPE" : "EVR", "Dispatch" : "PICT", "EventId" : 2, "Module" : "dispatcher", "Message" : "dispatch done!" },
          {"OBJ_TYPE" : "CHANNEL", "ChannelId" : 3, "DataNumber" : 6}, # change the data number
          {"OBJ_TYPE" : "EVR", "Success" : "PICT", "EventId" : 3, "Message" : "command succeeded!"},
          {"OBJ_TYPE" : "PRODUCT", "Name" : "Image", "ImageSize" : 1200}
       ]
                 
log3 = [
          {"OBJ_TYPE" : "COMMAND", "Stem" : "PICT"},
          {"OBJ_TYPE" : "EVR", "Dispatch" : "PICT", "EventId" : 2, "Module" : "dispatcher", "Message" : "dispatch done!"},
          # leave out CHANNEL
          {"OBJ_TYPE" : "EVR", "Success" : "PICT", "EventId" : 3, "Message" : "command succeeded!"},
          {"OBJ_TYPE" : "PRODUCT", "Name" : "Image", "ImageSize" : 1200}
       ]
                 
log4 = [
          {"OBJ_TYPE" : "COMMAND", "Stem" : "PICT"},
          {"OBJ_TYPE" : "EVR", "Dispatch" : "PICT", "EventId" : 2, "Module" : "dispatcher", "Message" : "dispatch done!"},
          {"OBJ_TYPE" : "CHANNEL", "ChannelId" : 3, "DataNumber" : 5},
          {"OBJ_TYPE" : "EVR", "Failure" : "PICT", "EventId" : 3, "Message" : "***command failed!"}, # failed command
          {"OBJ_TYPE" : "PRODUCT", "Name" : "Image", "ImageSize" : 1200}
       ]
                    
# specify absolute path of where results should be stored (.dot files and RESULT file):
          
resultdir = "/Users/khavelun/Desktop/MSLRESULT"
lsm.setResultDir(resultdir)
        
# specify what fields to learn from if they are not the default fields, which are:
# - for COMMAND : "Stem"
# - for EVR : "EventId","Module","Message","EventNumber"
# - for CHANNEL : "ChannelId","Module","DataNumber"
# - for CHANGE : "ChannelId","Module","DataNumber"
# - for PRODUCT : "Name"

lsm.fieldsEVR(["EventId","Module","Message"])
              
# learn a new automaton based on log1 and log2 in the same run:

learner = lsm.ConcreteLearner("LogPattern")
learner.learnlog(log1)
learner.learnlog(log2)
learner.dumpSpec(resultdir + "/LogPattern1.spec")

# refine the spec just stored in LogPattern1.spec by learning from a new log file.
# store result in LogPattern2.spec.

learner = lsm.ConcreteLearner("LogPattern",resultdir + "/LogPattern1.spec")
learner.learnlog(log3)
learner.dumpSpec(resultdir + "/LogPattern2.spec")

# monitor now a good (log1) and a bad (log4) log file:
        
obs = lsm.Observer(resultdir + "/LogPattern2.spec")
obs.monitor(log1)
obs.monitor(log4)
