

import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm
 
class TestRuntypeChecking(unittest.TestCase):
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec16")

    ### test 1 : int string ###

    def test1_1(self):                   
        '''expect int, see int'''
        log = [
                   COMMAND({'Name' : "test1"}),
                   EVR({'Number' : 1}),
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 
 
    def test1_2(self):                   
        '''expect int, see string'''
        log = [
                   COMMAND({'Name' : "test1"}),
                   EVR({'Number' : "1"}),
                   EVR({'Number' : 1}) # to avoid a spec violation
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([
            ["P1","EVR","Number",2,"integer or long expected - saw str"]
        ]) 

    ### test2 : string int ###

    def test2_1(self):
        '''expect string, see string'''
        log = [
                   COMMAND({'Name' : "test2"}),
                   EVR({'Number' : "1"}) 
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 

    def test2_2(self):                   
        '''expect string, see int'''
        log = [
                   COMMAND({'Name' : "test2"}),
                   EVR({'Number' : 1}),
                   EVR({'Number' : "1"}) # to avoid spec violation
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([
            ["P2","EVR","Number",2,"string or unicode expected - saw int"]
        ]) 

    ### test3 : int string for interval ###

    def test3_1(self):       
        '''expect int, see int, for interval'''            
        log = [
                   COMMAND({'Name' : "test3"}),
                   EVR({'Number' : 15}) 
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 

    def test3_2(self):
        '''expect int, see string, for interval'''                     
        log = [
                   COMMAND({'Name' : "test3"}),
                   EVR({'Number' : "15"}),
                   EVR({'Number' : 15}) # to avoid spec violation
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([
            ["P3","EVR","Number",2,"int or long expected - saw str"]
        ]) 

    ### test4 : int versus string for parameter  ###

    def test4_1(self):                   
        '''expect int, see int for parameter'''
        log = [
                   COMMAND({'Name' : "test4", 'Number' : 1}),
                   EVR({'Number' : 1}),
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 
 
    def test4_2(self):                   
        '''expect int, see string for parameter'''
        log = [
                   COMMAND({'Name' : "test4", 'Number' : 1}),
                   EVR({'Number' : "1"}),
                   EVR({'Number' : 1}) # to avoid a spec violation
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([
            ["P4","EVR","Number",2,"integer or long expected - saw str"]
        ]) 
  
    def test4_3(self):                   
        '''expect string, see string for parameter'''
        log = [
                   COMMAND({'Name' : "test4", 'Number' : "1"}),
                   EVR({'Number' : "1"}),
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 
 
    def test4_4(self):                   
        '''expect string, see int for parameter'''
        log = [
                   COMMAND({'Name' : "test4", 'Number' : "1"}),
                   EVR({'Number' : 1}),
                   EVR({'Number' : "1"}) # to avoid a spec violation
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([
            ["P4","EVR","Number",2,"string or unicode expected - saw int"]
        ]) 
  
    ### test5 : indexing with a string into a non-map ###
 
    def test5_1(self):                   
        '''expect map, see map'''
        log = [
                   COMMAND({'Name' : "test5"}),
                   EVR({'Map' : {"TEST" : "success"}}),
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 
 
    def test5_2(self):                   
        '''expect map, see int'''
        log = [
                   COMMAND({'Name' : "test5"}),
                   EVR({'Map' : 1}),
                   EVR({'Map' : {"TEST" : "success"}}), # to avoid a spec violation
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([
            ["P5","EVR","Map",2,"index into number must be an int"]
        ]) 
  
    ### test6 : indexing into number should require 0,1 ranges ###
 
    def test6_1(self):                   
        '''expect 0,1, see 0,1'''
        log = [
                   COMMAND({'Name' : "test6_1"}),
                   EVR({'Number' : 5})
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 
 
    def test6_2(self):                   
        '''expect 0,1, see strings 0,1'''
        log = [
                   COMMAND({'Name' : "test6_2"}),
                   EVR({'Number' : 5})
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([
            ["P6_2","EVR","Number",2,"result of indexing into number must be 0 or 1"]
        ]) 
  

### test7 : indexing into a string should require char ranges ###
 
    def test7_1(self):                   
        '''expect char, see char'''
        log = [
                   COMMAND({'Name' : "test7_1"}),
                   EVR({'Text' : "RV2009"})
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 
 
    def test7_2(self):                   
        '''expect char, see string of size > 1'''
        log = [
                   COMMAND({'Name' : "test7_2"}),
                   EVR({'Text' : "RV2009"})
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([
            ["P7_2","EVR","Text",2,"result of indexing into string must be a char"]
        ]) 

    def test7_3(self):
        '''expect char, see number'''  
        log = [
                   COMMAND({'Name' : "test7_3"}),
                   EVR({'Text' : "RV2009"})
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([
            ["P7_3","EVR","Text",2,"result of indexing into string must be a char"]
        ]) 
  
if __name__ == '__main__':
    unittest.main()
    