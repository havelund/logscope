

import lsm.lsm as lsm

log = [
          {"OBJ_TYPE" : "COMMAND", "Type" : "FlightSoftWare", "Name" : "PICT", "Time" : 1900},
          {"OBJ_TYPE" : "EVR", "Name" : "PICT", "Status" : "dispatch"},
          {"OBJ_TYPE" : "EVR", "Name" : "PICT", "Status" : "success", "Time" : 2950}        
       ]
           
lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")   
observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/www-example")
observer.monitor(log)
