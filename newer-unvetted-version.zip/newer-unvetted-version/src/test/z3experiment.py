
import lsm.lsm as lsm

log = [
    { # command
      "OBJ_TYPE" : "COMMAND",
      "Time" : 10,
      "Name" : "DRILL",
      "Type" : "FSW"
    },
    { # irrelevant event
      "OBJ_TYPE" : "EVR",
      "Time" : 20,
      "Msg"  : "so far so good"
    },
    { # success within required time
      "OBJ_TYPE" : "EVR",
      "Time" : 90,
      "Success" : "DRILL"
    },
    { # another success - this is an error error
      "OBJ_TYPE" : "EVR",
      "Time" : 98,
      "Success" : "DRILL"
    }
  ]
                      
lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")   

observer = lsm.Observer("specs/z3experiment-spec")

observer.monitor(log)
      
