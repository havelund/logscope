
# table of opcodes for all commands:
opcodes = {
    "TAKE_PIC"  :  20,
    "DRILL_DMP" : 42
    }

# function to extract opcode from table for a command:
def get_opcode(stem):
    return opcodes[stem]

