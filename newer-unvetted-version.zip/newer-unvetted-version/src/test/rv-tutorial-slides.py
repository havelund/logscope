
import lsm.lsm as lsm

log = [
    {
      "OBJ_TYPE" : "COMMAND",
      "Args" : ['CLEAR_RELAY_PYRO_STATUS'],
      "Time" : 51708322925696,
      "Stem" : "POWER_HOUSEKEEPING",
      "Number" : "4",
      "Type" : "FSW"
    },

    {
      "OBJ_TYPE" : "EVR", 
      "message" : "Dispatched immediate command\
         POWER_HOUSEKEEPING: number=4,\
         seconds=789006392, subseconds=1073741824.",
      "Dispatch" : "POWER_HOUSEKEEPING",
      "Time" : 51708322925696,
      "name" : "CMD_DISPATCH",
      "level" : "COMMAND",
      "Number" : "4"
    },

    {
      "OBJ_TYPE" : "EVR",
      "name" : "POWER_SEND_REQUEST",
      "Time" : 51708322925696,
      "message" : "power_queue_card_requestsending\
                    request to PAM 0.",
      "level" : "DIAGNOSTIC"
    },

    {
      "OBJ_TYPE" : "EVR",
      "message" : "Successfully completed command\
          POWER_HOUSEKEEPING: number=4.",
      "Success" : "POWER_HOUSEKEEPING",
      "Time" : 51708322944128,
      "name" : "CMD_COMPLETED_SUCCESS",
      "level" : "COMMAND",
      "Number" : "4"
    },

    {
      "OBJ_TYPE" : "EVR",
      "name" : "PWR_REQUEST_CALLBACK",
      "Time" : 51708322944128,
      "message" : "power_card_request -\
          FPGA request successfully sent to\
          RPAM A.",
      "level" : "DIAGNOSTIC"
    },

    {
      "OBJ_TYPE" : "CHANNEL",
      "channelId" : "PWR-3049",
      "DNChange" : 67,
      "dnUnsignedValue" : 1600,
      "type" : "UNSIGNED_INT",
      "Time" : 51708323217408,
      "ChannelName" : "PWR-BCB1-AMP"
    },

    {
      "OBJ_TYPE" : "COMMAND",
      "Args" : ['set_device(1)', 'TRUE'],
      "Time" : 51708372934400,
      "Stem" : "RUN_COMMAND",
      "Number" : "18",
      "Type" : "FSW"
    },
    
    {
      "OBJ_TYPE" : "EVR",
      "message" : "Validation failed for command\
          RUN_COMMAND: number=18.",
      "DispatchFailure" : "RUN_COMMAND",    
      "Time" : 51708372934499,
      "name" : "CMD_DISPATCH_VALIDATION_FAILURE",
      "level" : "COMMAND",
      "Number" : "18"
   }
  ]
                      
lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")   

observer = lsm.Observer("specs/rv-tutorial")

observer.monitor(log)
      