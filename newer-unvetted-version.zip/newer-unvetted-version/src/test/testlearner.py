 
import unittest
from lsm.unittest import *

from lsm.lsm import *

class TestLearner(unittest.TestCase):
 
    def test1(self):
          
        print "\n### set directory where various results are stored by default:\n" 
          
        resultdir = "/Users/khavelun/Desktop/MSLRESULT"
        setResultDir(resultdir)
        
        print "\n### read in the events and create example event logs:\n"
                
        events = unpickle_logfile("/Users/khavelun/Desktop/MSLPICKLE/pickled_events.pic")
        events1 = events[0:20]
        events2 = events[0:5] + events[7:8] + events[12:15]
        events3 = events[0:3] + events[10:19]
        events4 = events[0:8] + events[12:17]    
        events5 = events[0:2] + events[9:18]   

        print "\n### learn a new automaton based on 3 log files in the same run:\n"

        learner = ConcreteLearner("LogPattern")
        learner.learnlog(events1)
        learner.learnlog(events2)
        learner.learnlog(events3)
        learner.dumpSpec(resultdir + "/LogPattern1.spec")

        print "\n### refine an exisisting automaton by learning from a new log file:\n"

        learner = ConcreteLearner("LogPattern",resultdir + "/LogPattern1.spec")
        learner.learnlog(events4)
        learner.dumpSpec(resultdir + "/LogPattern2.spec")

        print "\n### monitor now a good and a bad log file:\n"
        
        obs = Observer(resultdir + "/LogPattern2.spec")
        checkErrorCount_(obs.monitor(events1),0)
        checkErrorCount_(obs.monitor(events2),0)
        checkErrorCount_(obs.monitor(events3),0)
        checkErrorCount_(obs.monitor(events4),0)
        checkErrors_(obs.monitor(events5), [
            {"K"  : "liveness", 
             "P" : "LogPattern",
             "M" : ["violated: event 3 terminates monitor in non-success state",
                      "violating event:",
                      "COMMAND",
                      "Stem := \"MOT_DMCA_CLF_SAVE\"",
                      "Number := \"10\"",
                      "reached state: L0_3",
                      "--- error trace: ---",
                      "Stem := \"DMX_SET_TX_CONFIG\"",
                      "Number := \"1\"",
                      "Stem := \"REMS_FP_DMP\"",
                      "Number := \"2\""]
            },
            {
             "K"  : "liveness", 
             "P" : "LogPattern",
             "M" : "none of the success states have been reached"
            }
        ]) 

if __name__ == '__main__':
    unittest.main()
