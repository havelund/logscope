
import lsm.lsm as lsm

log = [
    {
     "OBJ_TYPE" : "COMMAND",
     "Time" : 3700393,
     "Stem" : "DRILL_DMP",
     "Number" : "1",
     "Type" : "FSW"
    },

    {
     "OBJ_TYPE" : "EVR", 
     "Time" : 5030468,
     "Dispatch" : "DRILL_DMP",
     "message" : "Dispatched DRILL_DMP",
     "Number" : "1"
    },
    
    {
     "OBJ_TYPE" : "CHANGE",
     "Time" : 22736937,
     "Id" : "CMD-0004", 
     "Dn" : 42,
     "Dn_old" : 41
    },

    {
     "OBJ_TYPE" : "CHANGE",
     "Time" : 44937474,
     "Id" : "CMD-0009", 
     "Dn" : 101,
     "Dn_old" : 100
    },

    {
     "OBJ_TYPE" : "PRODUCT",
     "Time" : 320378725,
     "Name" : "DrillAll",
     "message" : "drill product",
     "Count" : 1
    },
    
    {
     "OBJ_TYPE" : "EVR",
     "Time" : 320378950,
     "Success" : "DRILL_DMP",
     "message" : "Completed DRILL_DMP",
     "Number" : "1"
    }
  ]
           
lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")   

observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/icse-spec")

observer.monitor(log)
      

