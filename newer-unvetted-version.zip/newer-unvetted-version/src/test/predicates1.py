
def lessThanOrEqual(x,y):
    return x <= y

