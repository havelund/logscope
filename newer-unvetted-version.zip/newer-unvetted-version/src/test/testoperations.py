
import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm
 
class TestOperations(unittest.TestCase):
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer([
                                      "/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec18",
                                      "/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec19"
                                ])
 
    def test1(self):                   
        '''should yield no errors'''
        log = [
                 COMMAND({'Name' : "cmd1"}),
                 COMMAND({'Name' : "cmd2"}),
                 COMMAND({'Name' : "cmd3"}),
                 COMMAND({'Name' : "cmd4"}),
                 EVR({'Success' :"cmd1"}),
                 EVR({'Success' :"cmd2"}),
                 EVR({'Success' :"cmd3"})
                  ]
        checkErrors_(self.observer.monitor(log),[])

    def test2(self):                   
        '''should yield errors'''
        log = [
                 COMMAND({'Name' : "cmd1"}),
                 COMMAND({'Name' : "cmd2"}),
                 COMMAND({'Name' : "cmd3"}),
                 COMMAND({'Name' : "cmd4"}),
                 EVR({'Success' :"cmd1"}),
                 EVR({'Success' :"cmd2"})
                  ]
        checkErrors_(self.observer.monitor(log),[
            {"K"  : "liveness", 
             "P" : "P1", 
             "M" : "hot end state", 
             "S" : "S2", 
             "B"  : {'x': 'cmd3'},
             "H"  : [COMMAND({'Name' : "cmd3"})]
            },
            {"K"  : "liveness", 
             "P" : "P3", 
             "M" : "hot end state", 
             "S" : "S2", 
             "B"  : {'x': 'cmd3'},
             "H"  : [COMMAND({'Name' : "cmd3"})]
            }     
        ])
                        
if __name__ == '__main__':
    unittest.main()
