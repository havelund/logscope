

import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm
 
class TestUptoScope(unittest.TestCase):
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec15")
 
    def test1(self):                   
        '''test 1: should yield no errors: spec : A => [B,!C,D] & !E & F upto COMMAND{} log : A B D F'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "B"}),
                   EVR({'Name' : "D"}),
                   EVR({'Name' : "F"}),
                  ]
        checkErrors_(self.observer.monitor(log),[])  

    def test2(self):                   
        '''test 2: should yield no errors: spec : A => [B,!C,D] & !E & F upto COMMAND{} log : A B D F Q'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "B"}),
                   EVR({'Name' : "D"}),
                   EVR({'Name' : "F"}),
                   COMMAND({'Name' : "Q"})
                  ]
        checkErrors_(self.observer.monitor(log),[])

    def test3(self):                   
        '''test 3:  should yield two safety violations: spec : A => [B,!C,D] & !E & F upto COMMAND{} log : A B Q D F'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "B"}),
                   COMMAND({'Name' : "Q"}),
                   EVR({'Name' : "D"}),
                   EVR({'Name' : "F"}),
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K" : "safety", 
             "P" : "P", 
             "M" :"violated: by event 3", 
             "S" : "S3", 
             "B" : {},
             "H" : [COMMAND({'Name' : "A"}), EVR({'Name' : "B"})],
             "N" : 3, 
             "E" : COMMAND({'Name' : "Q"}), 
             "T" : 3
           },
            {"K" : "safety", 
             "P" : "P", 
             "M" :"violated: by event 3", 
             "S" : "S6", 
             "B" : {},
             "H" : [COMMAND({'Name' : "A"})],
             "N" : 3, 
             "E" : COMMAND({'Name' : "Q"}), 
             "T" : 2
           }                                                                                                                              
        ])
                  
    def test4(self):                   
        '''test 4: should yield one safety violation: spec : A => [B,!C,D] & !E & F upto COMMAND{} log : A B D Q F'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "B"}),
                   EVR({'Name' : "D"}),
                   COMMAND({'Name' : "Q"}),
                   EVR({'Name' : "F"}),
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K" : "safety", 
             "P" : "P", 
             "M" :"violated: by event 4", 
             "S" : "S6", 
             "B" : {},
             "H" : [COMMAND({'Name' : "A"})],
             "N" : 4, 
             "E" : COMMAND({'Name' : "Q"}), 
             "T" : 2
           }                                                                                                                           
        ])

    def test5(self):                   
        '''test 5: should yield one safety violation: spec : A => [B,!C,D] & !E & F upto COMMAND{} log : A F B Q D'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "F"}),
                   EVR({'Name' : "B"}),
                   COMMAND({'Name' : "Q"}),
                   EVR({'Name' : "D"}),
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K" : "safety", 
             "P" : "P", 
             "M" :"violated: by event 4", 
             "S" : "S3", 
             "B" : {},
             "H" : [COMMAND({'Name' : "A"}), EVR({'Name' : "B"})],
             "N" : 4, 
             "E" : COMMAND({'Name' : "Q"}), 
             "T" : 3
           }                                                                                                                           
        ])
                    
if __name__ == '__main__':
    unittest.main()
