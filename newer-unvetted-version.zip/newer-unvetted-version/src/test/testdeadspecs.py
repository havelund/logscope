

import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm

class TestDeadSpecs(unittest.TestCase):
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec17")

    def test1(self):                   
        '''all specs are fired'''
        log = [
                   COMMAND({'Name' : "test1"}),
                   EVR({'Number' : 1}),
                   COMMAND({'Name' : "test2"}),
                   EVR({'Number' : 2}),                   
                   COMMAND({'Name' : "test3"}),
                   EVR({'Number' : 3}),
                   COMMAND({'Name' : "test4"}),
                   EVR({'Number' : 4})    
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 
        checkDeadSpecs(self.observer,[])

    def test2(self):                   
        '''two specs do not fire'''
        log = [
                   COMMAND({'Name' : "test1"}),
                   EVR({'Number' : 1}),
                   COMMAND({'Name' : "test2_NO_MATCH"}),
                   EVR({'Number' : 2}),                   
                   COMMAND({'Name' : "test3"}),
                   EVR({'Number' : 3}),
                   COMMAND({'Name' : "test4_NO_MATCH"}),
                   EVR({'Number' : 4})    
                  ]
        checkErrors_(self.observer.monitor(log),[])
        checkTypeErrors_([]) 
        checkDeadSpecs(self.observer,["P2","P4"])

 
if __name__ == '__main__':
    unittest.main()
