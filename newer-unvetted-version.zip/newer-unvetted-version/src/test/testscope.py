
import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm
 
class TestScope(unittest.TestCase):
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec14")
 
    #spec : A => [B,!C,D] & !E & F 
    def test1(self):                   
        '''should yield no errors'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "B"}),
                   EVR({'Name' : "D"}),
                   EVR({'Name' : "F"}),
                  ]
        checkErrors_(self.observer.monitor(log),[])  

    #spec : A => [B,!C,D] & !E & F  
    def test2(self):                   
        '''should yield no errors'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "B"}),
                   EVR({'Name' : "D"}),
                   EVR({'Name' : "F"}),
                   COMMAND({'Name' : "Q"})
                  ]
        checkErrors_(self.observer.monitor(log),[])

    #spec : A => [B,!C,D] & !E & F
    def test3(self):                   
        '''should yield two safety violations'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "B"}),
                   COMMAND({'Name' : "Q"}),
                   EVR({'Name' : "D"}),
                   EVR({'Name' : "F"}),
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K" : "safety", 
             "P" : "A", 
             "M" :"violated: by event 3", 
             "S" : "S3", 
             "B" : {},
             "H" : [COMMAND({'Name' : "A"}), EVR({'Name' : "B"})],
             "N" : 3, 
             "E" : COMMAND({'Name' : "Q"}), 
             "T" : 3
           },
            {"K" : "safety", 
             "P" : "A", 
             "M" :"violated: by event 3", 
             "S" : "S5", 
             "B" : {},
             "H" : [COMMAND({'Name' : "A"})],
             "N" : 3, 
             "E" : COMMAND({'Name' : "Q"}), 
             "T" : 2
           }                                                                                                                              
        ])
                  
    #spec : A => [B,!C,D] & !E & F
    def test4(self):                   
        '''should yield one safety violation'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "B"}),
                   EVR({'Name' : "D"}),
                   COMMAND({'Name' : "Q"}),
                   EVR({'Name' : "F"}),
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K" : "safety", 
             "P" : "A", 
             "M" :"violated: by event 4", 
             "S" : "S5", 
             "B" : {},
             "H" : [COMMAND({'Name' : "A"})],
             "N" : 4, 
             "E" : COMMAND({'Name' : "Q"}), 
             "T" : 2
           }                                                                                                                           
        ])

    #spec : A => [B,!C,D] & !E & F
    def test5(self):                   
        '''should yield one safety violation'''
        log = [
                   COMMAND({'Name' : "A"}),
                   EVR({'Name' : "F"}),
                   EVR({'Name' : "B"}),
                   COMMAND({'Name' : "Q"}),
                   EVR({'Name' : "D"}),
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K" : "safety", 
             "P" : "A", 
             "M" :"violated: by event 4", 
             "S" : "S3", 
             "B" : {},
             "H" : [COMMAND({'Name' : "A"}), EVR({'Name' : "B"})],
             "N" : 4, 
             "E" : COMMAND({'Name' : "Q"}), 
             "T" : 3
           }                                                                                                                           
        ])
                    
if __name__ == '__main__':
    unittest.main()
    
    