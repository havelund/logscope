
import unittest
from lsm.unittest import *
 
import lsm.lsm as lsm
 
class TestExpressionPredicates(unittest.TestCase):
 
    def setUp(self):
        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
        self.observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec13")
 
    def test1(self):                   
        '''should yield no errors'''
        log = [
                 COMMAND({'Left' : 10, 'Right' : 20}),
                 EVR({'Middle' : 15}),
                 EVR({'Number' :12})
                  ]
        checkErrors_(self.observer.monitor(log),[])

    def test2(self):                   
        '''should yield no errors'''
        log = [
                 COMMAND({'Left' : 10, 'Right' : 20}),
                 EVR({'Middle' : 15}),
                 EVR({'Number' :20})
                  ]
        checkErrors_(self.observer.monitor(log),[])

    def test3(self):                   
        '''M value is outside [L,R]'''
        log = [
                 COMMAND({'Left' : 10, 'Right' : 20}),
                 EVR({'Middle' : 21}), # M > R
                 EVR({'Number' :12})
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K"  : "liveness", 
             "P" : "P", 
             "M" : "hot end state", 
             "S" : "S2", 
             "B"  : {'R': 20, 'L': 10},
             "H"  : [COMMAND({'Left' : 10, 'Right' : 20})],
            }                                                                                                                         
        ])
        
    def test4(self):                   
        '''N value is outside [L,R]'''
        log = [
                 COMMAND({'Left' : 10, 'Right' : 20}),
                 EVR({'Middle' : 15}), 
                 EVR({'Number' :21}) # N > R 
                  ]
        checkErrors_(self.observer.monitor(log), [
            {"K" : "safety", 
             "P" : "P", 
             "M" :"violated: by event 3", 
             "S" : "S3", 
             "B" : {'R': 20, 'M': 15, 'L': 10},
             "H" : [COMMAND({'Left' : 10, 'Right' : 20}), EVR({'Middle' : 15})],
             "N" : 3, 
             "E" : EVR({'Number' : 21}), 
             "T" : 1
           }                                                                                                                                                     
        ])        
                        
if __name__ == '__main__':
    unittest.main()
    