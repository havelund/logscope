


import lsm.lsm as lsm

observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/margarets-spec")

        