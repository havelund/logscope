
import unittest
from lsm.unittest import *

import lsm.lsm as lsm
   
class TestParser(unittest.TestCase):

    def test1(self):        

        lsm.setResultDir("/Users/khavelun/Desktop/MSLRESULT")
   
        observer = lsm.Observer("/Users/khavelun/Desktop/development/workspace/mslsm/src/test/specs/spec20")
        events = lsm.unpickle_logfile("/Users/khavelun/Desktop/MSLPICKLE/pickled_events.pic")
        
        results = observer.monitor(events)
                 
if __name__ == '__main__':
    unittest.main()

