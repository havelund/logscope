
def LESS_THAN(x,y):
    return x < y

def EQUAL(x,y):
    return x == y

   