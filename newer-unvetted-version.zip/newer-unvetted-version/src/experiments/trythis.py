
opcodes = {
    "TAKE_PIC"  :  20,
    "DRILL_DMP" : 42
    }

def get_opcode(stem):
    return opcodes[stem]

print get_opcode("DRILL_DMP")
