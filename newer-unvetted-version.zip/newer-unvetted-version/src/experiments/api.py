

class SpecExecutive:
    def setDir(self,dir): pass
    def loadLog(self,session): pass
    def learn(self,learn =False,savelog = True): pass
    def monitor(self,log): pass
        