
import util.Utils
util.Utils.loadPythonPath()

import os
import sys
import time
import pickle
import command.cmd_sequencer as sequencer
import logmaker as lm
import lsm.lsm as lsm

import automated_testing.cmd_args as cmdArgs
import automated_testing.gen_cmds.channel_objects as chans
import automated_testing.gen_cmds.cmd_objects as cmds

class SpecExecutive(object):

    def __init__(self, seqList=None, specList=None):
        '''The constructor takes two optional parameters to define the sequences and monitors to be used.
        @param seqList A list of file names specifying the sequences to run or a list of Python lists of the command sequences.
        @param specList A list of the file names of the specifications to validate the monitor against.'''
        if specList:
            self._specList = specList
        else:
            self._specList = []
        
        self._seqList = []
        self.loadSequencers(seqList)
        
    
    def loadSequencers(self, seqList, clearList=True, delay=10):
        '''Loads the specified sequence lists into a list of sequencer objects.
        @param seqList A list of file names specifying the sequences to run or a list of Python lists of the command sequences.'''
        cmdSeq = sequencer.CmdSequencer(delay=delay)
        
        if clearList:
            self._seqList = []
        
        for seqItem in seqList:
            if isinstance(seqItem, list):
                cmdSeq.loadList(seqItem)
            elif isinstance(seqItem, str) or isinstance(seqItem, unicode):
                cmdSeq.loadFile(seqItem)
            else:
                sys.stderr.write("Sequence list not recognized. Must be a list of files, or a list of commands.")
                return
            self._seqList.append(cmdSeq)

    
    def runSequencers(self, sendRealTime=True):
        '''Run whatever sequencers have been loaded sequentially.
        @param sendRealTime Boolean that tracks whether to send in real time if True, or as a single batch file of commands if False.'''
        for seqItem in self._seqList:
            seqItem.send(sendRealTime=sendRealTime)
            

    def runMonitor(self, key, channelRestrictions = None):
        '''Monitors and creates a spec of the specified session.
        @param sessionKey Session key value to monitor.'''

        ts = time.strftime("%Y%m%d.%H%M%S")
        
        l = lm.LogMaker()
        
        # if specs available, check log against specs
        if len(self._specList) > 0:
            print "Checking logs against spec list"
            for spec in self._specList:
                if channelRestrictions:
                    l.check_log(timestamp=ts, key=key, spec=spec, channelRestrictions=channelRestrictions) #, commandRestrictions, EVRRestrictions, channelRestrictions, changeRestrictions, productRestrictions, addBits, dbName)
                else:
                    l.check_log(timestamp=ts, key=key, spec=spec)
        # else create logs and develop concrete learner
        else:
            print "Creating spec from logs"
            l.read_logs(key=key, channelRestrictions=channelRestrictions)
            
            lrn = lsm.ConcreteLearner(automatonName="spec_exec")
            lrn.learnlog(l.event_list)
            lrn.dumpSpec(os.environ["FIT_LOGS"] + "/spec_exec_" + str(ts))

#    # specify tests to run
#    def __init__(self):
#        self.lrnSpecFile = os.environ['FIT_LOGS']+self._testName+self.currentTest+time.localtime()+'.spec'
#        self.logfile =  os.environ['FIT_LOGS']+self._testName+self.currentTest+time.localtime()+'.log'
#        self.obsSpecFile = os.environ['FIT_LOGS']+self._testName+self.currentTest+time.localtime()+'.log'
#
#
#    # TODO fix paths and add them to object
#    def runSpec(self,learn =False,savelog = True):
#        self.lm.read_logs(key=pp.sessionId,
#                channelRestrictions = "(channelId LIKE 'PYRO%' OR channelId LIKE 'CMD%')",
#                EVRRestrictions = "(name LIKE 'PYRO%' OR name LIKE 'CMD%')"
#            )
#        if(saveLog):
#            lm.pickle_log(file='/home/cldelp/workspace/fit/logs/'+self._testName+self.currentTest+time.localtime())
#        if(learn):
#            self.spec = lsm.Specification()
#            lrn = lsm.ExactLearner(self.spec)
#            lrn.learnLog(lm.event_list)
#            lrn.dumpSpec(self._testName+self.currentTest+time.localtime()+'.spec')
#        else:
#            self.obs = lsm.Obsrver(self.TestName+'.spec')
#            self.obs.monitor(lm.event_list)


if __name__ == "__main__":
    
    # specify the sequences to be run by the SpecExecutive
    seqList = ["../../../silo/S20_ScienceInstruments/mini_checkout/rad_mini_checkout.cmd",]
    specList = [os.environ["FIT_LOGS"] + "/spec_exec_20081208.223333",]
#    specList = None
    spexec = SpecExecutive(seqList=seqList, specList=specList)
    
    # run the sequences, specifying whether to run in real time or not
#    spexec.runSequencers(sendRealTime=True)

    # run the monitor with the specified channel restrictions (necessary otherwise the event list is way too large... unfortunately...)
    channelRestrictions = "(channelId LIKE 'CMD%' OR channelID LIKE 'RAD%')"
    spexec.runMonitor(key=56, channelRestrictions=channelRestrictions)
    