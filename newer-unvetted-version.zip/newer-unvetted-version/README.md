## LogScope - Newer Version

This is a newer version of LogScope, which needs to be examined and compared to the current version before being installed.

